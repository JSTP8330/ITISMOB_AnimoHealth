package com.itismob.s15.group6.mco2.animohealth

import android.graphics.Bitmap
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class QrDemoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_qr_demo)

        val imageView = findViewById<ImageView>(R.id.imageViewQr)
        val btnGenerate = findViewById<Button>(R.id.btnGenerate)

        btnGenerate.setOnClickListener {
            val payload = QrUtils.createAppointmentPayload(
                appointmentId = "demo-appt-001",
                userId = "demo-user-123",
                timestampMillis = System.currentTimeMillis()
            )
            val bmp: Bitmap = QrUtils.generateQrBitmap(payload, size = 600)
            imageView.setImageBitmap(bmp)
            // optionally save: QrUtils.saveBitmapToGallery(this, bmp, "demo-appt-001.png")
        }

        // Generate one on create for demo
        btnGenerate.performClick()
    }
}


package com.itismob.s15.group6.mco2.animohealth

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.itismob.s15.group6.mco2.animohealth.utils.SharedPrefsHelper
import com.google.firebase.auth.FirebaseAuth
import java.util.Calendar
import android.app.DatePickerDialog

class RegisterActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()

        val nameEditText: EditText = findViewById(R.id.nameEditText)
        val studentNumberEditText: EditText = findViewById(R.id.studentIdEditText)
        val emailEditText: EditText = findViewById(R.id.emailEditText)
        val passwordEditText: EditText = findViewById(R.id.passwordEditText)
        val confirmPasswordEditText: EditText = findViewById(R.id.confirmPasswordEditText)
        val birthdateEditText: EditText = findViewById(R.id.birthdateEditText)
        val genderSpinner: Spinner = findViewById(R.id.genderSpinner)
        val createAccountButton: Button = findViewById(R.id.createAccountButton)
        val signInText: android.widget.TextView = findViewById(R.id.signInText)

        birthdateEditText.setOnClickListener {
            val calendar = Calendar.getInstance()
            DatePickerDialog(
                this,
                { _, year, month, day ->
                    birthdateEditText.setText("$year-${month + 1}-$day")
                },
                2000,
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        createAccountButton.setOnClickListener {
            val name = nameEditText.text.toString().trim()
            val studentId = studentNumberEditText.text.toString()
            val email = emailEditText.text.toString().trim().lowercase()
            val password = passwordEditText.text.toString()
            val confirmPassword = confirmPasswordEditText.text.toString()
            val birthdate = birthdateEditText.text.toString()
            val gender = genderSpinner.selectedItem.toString()

            when {
                name.isEmpty() -> Toast.makeText(this, "Please enter your name", Toast.LENGTH_SHORT).show()
                studentId.isEmpty() -> Toast.makeText(this, "Please enter your student ID", Toast.LENGTH_SHORT).show()
                !email.endsWith("@dlsu.edu.ph") -> Toast.makeText(this, "Please use your DLSU email", Toast.LENGTH_SHORT).show()
                password.isEmpty() || password.length < 6 -> Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
                password != confirmPassword -> Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
                birthdate.isEmpty() -> Toast.makeText(this, "Please enter your birthdate", Toast.LENGTH_SHORT).show()
                else -> {
                    // Create user with Firebase Authentication
                    auth.createUserWithEmailAndPassword(email, password)
                        .addOnSuccessListener { authResult ->
                            val userId = authResult.user?.uid ?: return@addOnSuccessListener

                            // Store additional user data in Firestore
                            FirestoreHelper.addUser(userId, name, email) { success ->
                                if (success) {
                                    // Update with studentId
                                    FirestoreHelper.updateUser(userId, mapOf("studentId" to studentId)) { _ -> }
                                    // Update with birthdate
                                    FirestoreHelper.updateUser(userId, mapOf("birthDate" to birthdate)) { _ -> }
                                    // Update with gender
                                    FirestoreHelper.updateUser(userId, mapOf("gender" to gender)) { _ -> }
                                    // Set phone and emergency contact in default state
                                    FirestoreHelper.updateUser(userId, mapOf("phone" to "Not set", "emergencyContact" to "Not set")) { _ -> }

                                    Toast.makeText(this, "Registration successful! Please login.", Toast.LENGTH_SHORT).show()
                                    startActivity(Intent(this, LoginActivity::class.java))
                                    finish()
                                } else {
                                    Toast.makeText(this, "Registration failed. Please try again.", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                        .addOnFailureListener { e ->
                            Toast.makeText(this, "Registration failed: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                }
            }
        }

        signInText.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }


    }
}

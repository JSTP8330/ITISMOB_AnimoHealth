package com.itismob.s15.group6.mco2.animohealth

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.widget.CalendarView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.itismob.s15.group6.mco2.animohealth.adapter.AppointmentCalendarAdapter
import com.itismob.s15.group6.mco2.animohealth.model.Appointment
import com.itismob.s15.group6.mco2.animohealth.utils.SharedPrefsHelper
import java.text.SimpleDateFormat
import java.util.*

class CalendarActivity : AppCompatActivity() {

    private lateinit var clinicCalendar: CalendarView
    private lateinit var appointmentRecycler: RecyclerView
    private lateinit var appointmentAdapter: AppointmentCalendarAdapter
    private lateinit var dateHeaderText: TextView
    private lateinit var conflictIndicator: TextView

    private var currentUserId = ""
    private var selectedDate = ""
    private var userAppointments = mutableListOf<Appointment>()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calendar)

        clinicCalendar = findViewById(R.id.clinicCalendar)
        appointmentRecycler = findViewById(R.id.appointmentRecyclerView)
        dateHeaderText = findViewById(R.id.dateHeaderText)
        conflictIndicator = findViewById(R.id.conflictIndicator)

        currentUserId = SharedPrefsHelper.getCurrentUserId(this) ?: run {
            Toast.makeText(this, "User not authenticated", Toast.LENGTH_SHORT).show()
            finish()
            return@run ""
        }

        if (currentUserId.isEmpty()) {
            finish()
            return
        }

        appointmentAdapter = AppointmentCalendarAdapter(mutableListOf(), currentUserId)
        appointmentRecycler.layoutManager = LinearLayoutManager(this)
        appointmentRecycler.adapter = appointmentAdapter
        appointmentRecycler.isNestedScrollingEnabled = false

        selectedDate = dateFormat.format(Calendar.getInstance().time)
        updateDateHeader()

        loadAppointments()

        clinicCalendar.setOnDateChangeListener { _, year, month, dayOfMonth ->
            val calendar = Calendar.getInstance()
            calendar.set(year, month, dayOfMonth)
            selectedDate = dateFormat.format(calendar.time)
            updateDateHeader()
            updateAppointmentsForDate()
        }
    }

    private fun loadAppointments() {
        FirestoreHelper.getAppointments(currentUserId) { userAppts ->
            userAppointments = userAppts.toMutableList()
            Log.d("CalendarActivity", "Loaded ${userAppointments.size} user appointments")

            FirestoreHelper.getAllAppointments { allAppts ->
                val allAppointments = allAppts.toMutableList()
                Log.d("CalendarActivity", "Loaded ${allAppointments.size} total appointments")
                
                // Get appointments for selected date
                val appointmentsOnDate = allAppointments.filter { it.date == selectedDate }
                
                // Pass all appointments to adapter for conflict detection
                appointmentAdapter.setAllAppointments(appointmentsOnDate)
                
                // Show only user's appointments for this date
                val userAppointmentsOnDate = userAppointments.filter { it.date == selectedDate }
                appointmentAdapter.updateAppointments(userAppointmentsOnDate)
                
                updateConflictIndicator(appointmentsOnDate, userAppointmentsOnDate)
            }
        }
    }

    private fun updateAppointmentsForDate() {
        FirestoreHelper.getAllAppointments { allAppts ->
            val allAppointments = allAppts.toMutableList()
            
            // Get appointments for selected date
            val appointmentsOnDate = allAppointments.filter { it.date == selectedDate }
            
            // Pass all appointments to adapter for conflict detection
            appointmentAdapter.setAllAppointments(appointmentsOnDate)
            
            // Show only user's appointments for this date
            val userAppointmentsOnDate = userAppointments.filter { it.date == selectedDate }
            appointmentAdapter.updateAppointments(userAppointmentsOnDate)
            
            updateConflictIndicator(appointmentsOnDate, userAppointmentsOnDate)
        }
    }

    private fun updateConflictIndicator(allAppts: List<Appointment>, userAppts: List<Appointment>) {
        // Count conflicts for user's appointments
        var conflictCount = 0
        userAppts.forEach { userAppt ->
            val conflicts = allAppts.filter { other ->
                other.id != userAppt.id && hasTimeOverlap(userAppt, other)
            }
            if (conflicts.isNotEmpty()) conflictCount++
        }

        if (conflictCount > 0) {
            conflictIndicator.text = "⚠️ $conflictCount Conflict(s)"
            conflictIndicator.setTextColor(resources.getColor(android.R.color.holo_red_light, null))
        } else {
            conflictIndicator.text = "✓ No Conflicts"
            conflictIndicator.setTextColor(resources.getColor(android.R.color.holo_green_light, null))
        }
    }

    private fun hasTimeOverlap(appt1: Appointment, appt2: Appointment): Boolean {
        val time1 = appt1.time.split("-")
        val time2 = appt2.time.split("-")
        if (time1.size < 2 || time2.size < 2) return false
        val start1 = time1[0].trim()
        val end1 = time1[1].trim()
        val start2 = time2[0].trim()
        val end2 = time2[1].trim()
        return start1 < end2 && start2 < end1
    }

    private fun updateDateHeader() {
        val calendar = Calendar.getInstance()
        calendar.time = dateFormat.parse(selectedDate) ?: Date()
        val displayFormat = SimpleDateFormat("EEEE, MMM dd, yyyy", Locale.getDefault())
        dateHeaderText.text = displayFormat.format(calendar.time)
    }
}

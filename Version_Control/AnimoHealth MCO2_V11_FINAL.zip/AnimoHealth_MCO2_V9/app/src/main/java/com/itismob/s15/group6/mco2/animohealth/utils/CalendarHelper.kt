package com.itismob.s15.group6.mco2.animohealth.utils

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CalendarContract
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

object CalendarHelper {

    fun hasCalendarPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.WRITE_CALENDAR
        ) == PackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CALENDAR
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Add appointment to device calendar using Calendar Provider
     */
    fun addAppointmentToCalendar(
        context: Context,
        title: String,
        description: String,
        location: String,
        date: String,
        time: String
    ): Long? {
        if (!hasCalendarPermission(context)) {
            Toast.makeText(context, "Calendar permission required", Toast.LENGTH_SHORT).show()
            return null
        }

        try {
            val startMillis = parseDateTime(date, time)
            val endMillis = startMillis + (30 * 60 * 1000) // 30 minutes duration

            val values = ContentValues().apply {
                put(CalendarContract.Events.DTSTART, startMillis)
                put(CalendarContract.Events.DTEND, endMillis)
                put(CalendarContract.Events.TITLE, title)
                put(CalendarContract.Events.DESCRIPTION, description)
                put(CalendarContract.Events.EVENT_LOCATION, location)
                put(CalendarContract.Events.CALENDAR_ID, getCalendarId(context))
                put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
                put(CalendarContract.Events.HAS_ALARM, 1)
            }

            val uri = context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
            val eventId = uri?.lastPathSegment?.toLongOrNull()

            // Add reminders
            if (eventId != null) {
                addReminder(context, eventId, 24 * 60) // 1 day before
                addReminder(context, eventId, 3 * 24 * 60) // 3 days before
            }

            Toast.makeText(context, "Added to calendar", Toast.LENGTH_SHORT).show()
            return eventId
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Failed to add to calendar: ${e.message}", Toast.LENGTH_SHORT).show()
            return null
        }
    }

    /**
     * Open calendar app with intent to add event
     */
    fun openCalendarIntent(
        context: Context,
        title: String,
        description: String,
        location: String,
        date: String,
        time: String
    ) {
        try {
            val startMillis = parseDateTime(date, time)
            val endMillis = startMillis + (30 * 60 * 1000)

            val intent = Intent(Intent.ACTION_INSERT).apply {
                data = CalendarContract.Events.CONTENT_URI
                putExtra(CalendarContract.Events.TITLE, title)
                putExtra(CalendarContract.Events.DESCRIPTION, description)
                putExtra(CalendarContract.Events.EVENT_LOCATION, location)
                putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMillis)
                putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endMillis)
                putExtra(CalendarContract.Events.HAS_ALARM, 1)
            }

            context.startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Failed to open calendar", Toast.LENGTH_SHORT).show()
        }
    }

    private fun addReminder(context: Context, eventId: Long, minutesBefore: Int) {
        val reminderValues = ContentValues().apply {
            put(CalendarContract.Reminders.EVENT_ID, eventId)
            put(CalendarContract.Reminders.MINUTES, minutesBefore)
            put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
        }
        context.contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, reminderValues)
    }

    private fun getCalendarId(context: Context): Long {
        val projection = arrayOf(CalendarContract.Calendars._ID)
        val cursor = context.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            projection,
            null,
            null,
            null
        )

        cursor?.use {
            if (it.moveToFirst()) {
                return it.getLong(0)
            }
        }
        return 1L // Default calendar ID
    }

    private fun parseDateTime(date: String, time: String): Long {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.getDefault())
        val dateTimeString = "$date $time"
        return dateFormat.parse(dateTimeString)?.time ?: System.currentTimeMillis()
    }

    /**
     * Delete appointment from calendar
     */
    fun deleteAppointmentFromCalendar(context: Context, eventId: Long): Boolean {
        if (!hasCalendarPermission(context)) {
            return false
        }

        try {
            val uri = CalendarContract.Events.CONTENT_URI
            val deleteUri = Uri.withAppendedPath(uri, eventId.toString())
            val rows = context.contentResolver.delete(deleteUri, null, null)
            return rows > 0
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }
}


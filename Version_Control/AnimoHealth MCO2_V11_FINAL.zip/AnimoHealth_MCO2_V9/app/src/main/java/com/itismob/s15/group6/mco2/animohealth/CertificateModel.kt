package com.itismob.s15.group6.mco2.animohealth.model

data class Certificate(
    val id: String,
    val title: String,
    val issuedDate: String, // e.g. "2024-02-15"
    val expiryDate: String, // e.g. "2025-02-15"
    val status: String,      // e.g. "Valid", "Expiring Soon"
    val userIdCert: String    // User ID of the user who received the certificate
)

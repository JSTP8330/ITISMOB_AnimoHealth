package com.itismob.s15.group6.mco2.animohealth.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.itismob.s15.group6.mco2.animohealth.R
import com.itismob.s15.group6.mco2.animohealth.model.Appointment

class AppointmentCalendarAdapter(
    private var appointments: MutableList<Appointment>,
    private val currentUserId: String
) : RecyclerView.Adapter<AppointmentCalendarAdapter.AppointmentViewHolder>() {

    private var expandedPosition = -1
    private var allAppointments: List<Appointment> = emptyList()

    fun setAllAppointments(appointments: List<Appointment>) {
        this.allAppointments = appointments
    }

    inner class AppointmentViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val titleText: TextView = itemView.findViewById(R.id.appointmentTitle)
        private val timeText: TextView = itemView.findViewById(R.id.appointmentTime)
        private val statusBadge: TextView = itemView.findViewById(R.id.appointmentStatus)
        private val userIndicator: TextView = itemView.findViewById(R.id.userIndicator)
        private val conflictIcon: ImageView = itemView.findViewById(R.id.conflictIcon)
        private val expandButton: TextView = itemView.findViewById(R.id.expandButton)
        private val conflictDetailsContainer: LinearLayout? = itemView.findViewById(R.id.conflictDetailsContainer)
        private val detailsText: TextView? = itemView.findViewById(R.id.detailsText)

        fun bind(appointment: Appointment, position: Int) {
            titleText.text = appointment.title
            timeText.text = appointment.time

            statusBadge.text = appointment.status.uppercase()
            statusBadge.setBackgroundColor(getStatusColor(itemView.context, appointment.status))
            statusBadge.setTextColor(ContextCompat.getColor(itemView.context, android.R.color.white))

            val isCurrentUser = appointment.userIdApp == currentUserId
            if (isCurrentUser) {
                userIndicator.text = "👤 MY APPOINTMENT"
                userIndicator.setTextColor(ContextCompat.getColor(itemView.context, android.R.color.holo_blue_dark))
            } else {
                userIndicator.text = "👥 OTHER"
                userIndicator.setTextColor(ContextCompat.getColor(itemView.context, android.R.color.darker_gray))
            }

            showSimpleConflicts(appointment, allAppointments)

            expandButton.setOnClickListener {
                if (expandedPosition == position) {
                    expandedPosition = -1
                    conflictDetailsContainer?.visibility = View.GONE
                    expandButton.text = "⬇️ Show Conflicts"
                } else {
                    expandedPosition = position
                    conflictDetailsContainer?.visibility = View.VISIBLE
                    expandButton.text = "⬆️ Hide Conflicts"
                }
                notifyItemChanged(position)
            }

            if (appointment.details.isNotEmpty()) {
                detailsText?.text = appointment.details
            }
        }

        private fun getStatusColor(context: Context, status: String): Int {
            return when (status.lowercase()) {
                "completed" -> ContextCompat.getColor(context, android.R.color.holo_green_light)
                "pending" -> ContextCompat.getColor(context, android.R.color.holo_blue_light)
                "cancelled" -> ContextCompat.getColor(context, android.R.color.holo_red_light)
                else -> ContextCompat.getColor(context, android.R.color.darker_gray)
            }
        }

        private fun hasTimeOverlap(appt1: Appointment, appt2: Appointment): Boolean {
            val time1 = appt1.time.split("-")
            val time2 = appt2.time.split("-")
            if (time1.size < 2 || time2.size < 2) return false
            val start1 = time1[0].trim()
            val end1 = time1[1].trim()
            val start2 = time2[0].trim()
            val end2 = time2[1].trim()
            return start1 < end2 && start2 < end1
        }

        private fun showSimpleConflicts(appointment: Appointment, allAppointments: List<Appointment>) {
            val conflicts = allAppointments.filter { other ->
                other.id != appointment.id && hasTimeOverlap(appointment, other)
            }

            if (conflicts.isNotEmpty()) {
                val conflictList = conflicts.joinToString("\n") { "⚠️ ${it.title} - ${it.time}" }
                detailsText?.text = conflictList
                conflictIcon.visibility = View.VISIBLE
            } else {
                detailsText?.text = ""
                conflictIcon.visibility = View.GONE
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppointmentViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_appointment_calendar, parent, false)
        return AppointmentViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: AppointmentViewHolder, position: Int) {
        holder.bind(appointments[position], position)
    }

    override fun getItemCount() = appointments.size

    fun updateAppointments(newAppointments: List<Appointment>) {
        appointments = newAppointments.toMutableList()
        expandedPosition = -1
        notifyDataSetChanged()
    }

    fun addAppointment(appointment: Appointment) {
        appointments.add(appointment)
        notifyItemInserted(appointments.size - 1)
    }

    fun removeAppointment(position: Int) {
        appointments.removeAt(position)
        notifyItemRemoved(position)
    }
}

package com.itismob.s15.group6.mco2.animohealth.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.itismob.s15.group6.mco2.animohealth.R
import com.itismob.s15.group6.mco2.animohealth.FirestoreHelper
import com.itismob.s15.group6.mco2.animohealth.model.Appointment

open class HistoryAdapter(
    private val items: MutableList<Appointment>,
    private val showDeleteButton: Boolean
) : RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder>() {

    class HistoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.appointmentTitle)
        val status: TextView = view.findViewById(R.id.appointmentStatus)
        val dateTime: TextView = view.findViewById(R.id.appointmentDateTime)
        val details: TextView = view.findViewById(R.id.appointmentDetails)
        val appointmentButtons: View = view.findViewById(R.id.appointmentButtons)
        val deleteButton: Button = view.findViewById(R.id.appointmentDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_appointment, parent, false)
        return HistoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        val appointment = items[position]
        holder.title.text = appointment.title
        holder.status.text = appointment.status
        holder.dateTime.text = "${appointment.date} · ${appointment.time}"
        holder.details.text = appointment.details
        holder.status.setTextColor(
            ContextCompat.getColor(holder.itemView.context, when (appointment.status) {
                "Completed" -> R.color.green_200
                "Confirmed" -> R.color.blue_500
                "Incomplete" -> R.color.yellow_500
                else -> R.color.black
            })
        )
        // Show delete button only in History/Profile
        if (showDeleteButton) {
            holder.appointmentButtons.visibility = View.VISIBLE
            holder.deleteButton.visibility = View.VISIBLE
            holder.deleteButton.setOnClickListener {
                FirestoreHelper.deleteAppointment(appointment.id) { success ->
                    if (success) {
                        items.removeAt(position)
                        notifyItemRemoved(position)
                        Toast.makeText(
                            holder.itemView.context,
                            "Appointment deleted successfully",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        Toast.makeText(
                            holder.itemView.context,
                            "Failed to delete appointment",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        } else {
            holder.deleteButton.visibility = View.GONE
        }

    }

    override fun getItemCount(): Int = items.size
}

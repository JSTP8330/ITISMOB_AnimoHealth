package com.itismob.s15.group6.mco2.animohealth
import com.itismob.s15.group6.mco2.animohealth.utils.SharedPrefsHelper
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.auth.FirebaseAuth
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.GoogleAuthProvider

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts

class LoginActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()
    private lateinit var auth: FirebaseAuth
    private lateinit var googleSignInClient: GoogleSignInClient

    private val googleSignInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)
            if (account != null) {
                // Check if email is @dlsu.edu.ph
                if (account.email?.endsWith("@dlsu.edu.ph") == true) {
                    firebaseAuthWithGoogle(account)
                } else {
                    Toast.makeText(this, "Please use your DLSU email (@dlsu.edu.ph)", Toast.LENGTH_LONG).show()
                    googleSignInClient.signOut()
                }
            }
        } catch (e: ApiException) {
            Toast.makeText(this, "Google sign in failed: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_login)

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()

        // Configure Google Sign-In
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        googleSignInClient = GoogleSignIn.getClient(this, gso)

        val emailEditText: EditText = findViewById(R.id.emailEditText)
        val passwordEditText: EditText = findViewById(R.id.passwordEditText)
        val signInButton: Button = findViewById(R.id.signInButton)
        val googleSignInButton: Button = findViewById(R.id.googleSignInButton)
        val signUpText: TextView = findViewById(R.id.signUpText)

        // Email/Password Sign In
        signInButton.setOnClickListener {
            val email = emailEditText.text.toString().trim().lowercase()
            val password = passwordEditText.text.toString()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!email.endsWith("@dlsu.edu.ph")) {
                Toast.makeText(this, "Please use your university email address", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Sign in with Firebase Auth
            auth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener { authResult ->
                    val userId = authResult.user?.uid ?: return@addOnSuccessListener
                    SharedPrefsHelper.setLoggedIn(this, true)
                    SharedPrefsHelper.setCurrentUserId(this, userId)
                    startActivity(Intent(this, HomeActivity::class.java))
                    finish()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Login failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        }

        // Google Sign-In Button
        googleSignInButton.setOnClickListener {
            signInWithGoogle()
        }

        signUpText.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun signInWithGoogle() {
        val signInIntent = googleSignInClient.signInIntent
        googleSignInLauncher.launch(signInIntent)
    }

    private fun firebaseAuthWithGoogle(account: GoogleSignInAccount) {
        val credential = GoogleAuthProvider.getCredential(account.idToken, null)
        auth.signInWithCredential(credential)
            .addOnSuccessListener { authResult ->
                val user = authResult.user
                if (user != null) {
                    val userId = user.uid
                    val name = user.displayName ?: ""
                    val email = user.email ?: ""

                    // Check if user exists in Firestore, if not create
                    FirestoreHelper.getUser(userId) { userData ->
                        if (userData == null) {
                            // New user - create Firestore record
                            FirestoreHelper.addUser(userId, name, email) { success ->
                                if (success) {
                                    SharedPrefsHelper.setLoggedIn(this, true)
                                    SharedPrefsHelper.setCurrentUserId(this, userId)
                                    startActivity(Intent(this, HomeActivity::class.java))
                                    finish()
                                } else {
                                    Toast.makeText(this, "Failed to create user profile", Toast.LENGTH_SHORT).show()
                                }
                            }
                        } else {
                            // Existing user
                            SharedPrefsHelper.setLoggedIn(this, true)
                            SharedPrefsHelper.setCurrentUserId(this, userId)
                            startActivity(Intent(this, HomeActivity::class.java))
                            finish()
                        }
                    }
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Authentication failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}

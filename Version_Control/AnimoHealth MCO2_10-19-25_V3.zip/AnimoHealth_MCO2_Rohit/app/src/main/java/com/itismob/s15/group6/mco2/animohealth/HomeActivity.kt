package com.itismob.s15.group6.mco2.animohealth

import android.os.Bundle
import android.content.Intent
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.itismob.s15.group6.mco2.animohealth.adapter.HistoryAdapter
import com.itismob.s15.group6.mco2.animohealth.utils.SharedPrefsHelper

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppData.initializeDemoData()

        setContentView(R.layout.activity_home)

        // Dynamic greeting text logic
        val greetingText: TextView = findViewById(R.id.greetingText)

        // Get current user from SharedPrefs and AppData
        val userId = SharedPrefsHelper.getCurrentUserId(this)
        val user = AppData.users.find { it.id == userId }

        // Extract the first part of the user's name (first word before any spaces)
        val firstName = user?.name?.trim()?.split(" ")?.firstOrNull()?.replaceFirstChar { it.uppercase() } ?: "User"

        // Set the greeting text
        greetingText.text = "Hi, $firstName!"

        // Buttons
        val bookNowButton: Button = findViewById(R.id.bookNowButton)
        bookNowButton.setOnClickListener {
            startActivity(Intent(this, BookActivity::class.java))
        }

        val checkInButton: Button = findViewById(R.id.checkInButton)
        checkInButton.setOnClickListener {
            startActivity(Intent(this, CheckInActivity::class.java))
        }

        // Appointment Stats
        val totalAppointments = findViewById<TextView>(R.id.statsTotalAppointments)
        val completedAppointments = findViewById<TextView>(R.id.statsCompletedAppointments)
        totalAppointments.text = "${AppData.appointments.size}"
        completedAppointments.text = "${AppData.appointments.count { it.status == "Completed" }}"

        // Upcoming Appointments List
        val upcomingAppointments = AppData.appointments
            .filter { it.status != "Completed" }
            .sortedBy { it.date }

        val upcomingRecycler = findViewById<RecyclerView>(R.id.recyclerHistory)
        val upcomingAdapter = HistoryAdapter(upcomingAppointments)
        upcomingRecycler.layoutManager = LinearLayoutManager(this)
        upcomingRecycler.adapter = upcomingAdapter
        upcomingRecycler.isNestedScrollingEnabled = false

        // Bottom Navigation
        val navHome: Button = findViewById(R.id.navHome)
        val navBook: Button = findViewById(R.id.navBook)
        val navProfile: Button = findViewById(R.id.navProfile)

        navHome.setOnClickListener {
            // Stay on Home
        }
        navBook.setOnClickListener {
            startActivity(Intent(this, BookActivity::class.java))
        }
        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }
    }
}
package com.itismob.s15.group6.mco2.animohealth

import com.itismob.s15.group6.mco2.animohealth.model.Appointment
import com.itismob.s15.group6.mco2.animohealth.model.Certificate
import com.itismob.s15.group6.mco2.animohealth.model.User

object AppData {
    val appointments = mutableListOf<Appointment>()
    val certificates = mutableListOf<Certificate>()
    val users = mutableListOf<User>()

    fun initializeDemoData() {
        if (appointments.isEmpty()) {
            appointments.add(Appointment(0,"Annual Check-up", "2024-10-20", "10:00 AM", "All vitals normal.", "Completed"))
            appointments.add(Appointment(1,"Dental Check-up", "2025-08-05", "11:00 AM", "Routine cleaning completed. No issues found.", "Completed"))
            appointments.add(Appointment(2,"Drug Testing", "2025-08-25", "11:00 AM", "All signs clear. No issues found.", "Completed"))
            appointments.add(Appointment(3,"Annual Check-Up", "2025-10-20", "2:30 PM", "Date and time confirmed.", "Confirmed"))
        }
        if (certificates.isEmpty()) {
            certificates.add(Certificate(0,"Annual Check-up", "2024-10-20", "2025-10-27", "Expiring Soon"))
            certificates.add(Certificate(1,"Dental Check-up", "2025-08-05", "2026-08-12", "Valid"))
            certificates.add(Certificate(2,"Drug Testing", "2025-08-25", "2026-09-01", "Valid"))
        }
        if (users.isEmpty()) {
            users.add(User(0, "jd@dlsu.edu.ph", "1234", "Juan", "12510192", "2000-10-20", "Male", "639174567890", "639654321029"))
        }
    }

}

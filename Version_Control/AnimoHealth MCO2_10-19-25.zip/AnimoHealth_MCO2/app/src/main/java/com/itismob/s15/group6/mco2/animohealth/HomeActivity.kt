package com.itismob.s15.group6.mco2.animohealth

import android.os.Bundle
import android.content.Intent
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.itismob.s15.group6.mco2.animohealth.adapter.HistoryAdapter

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppData.initializeDemoData()

        setContentView(R.layout.activity_home)

        // TODO: Dynamic user display logic.

        val greetingText: TextView = findViewById(R.id.greetingText)
        greetingText.text = "Hi, test!"

        val bookNowButton: Button = findViewById(R.id.bookNowButton)
        bookNowButton.setOnClickListener {
            startActivity(Intent(this, BookActivity::class.java))
        }

        val checkInButton: Button = findViewById(R.id.checkInButton)
        checkInButton.setOnClickListener {
            startActivity(Intent(this, CheckInActivity::class.java))
        }

        // TODO: Add more logic for stats (only updates when "refreshed", upcoming appointments.

        // User Appointment Stats
        val totalAppointments = findViewById<TextView>(R.id.statsTotalAppointments)
        val completedAppointments = findViewById<TextView>(R.id.statsCompletedAppointments)
        totalAppointments.text = "${AppData.appointments.size}"
        completedAppointments.text = "${AppData.appointments.count { it.status == "Completed" }}"

        // TODO: Implement Check-In and Check-In Activity, as well as Calendar.

        // Filter and sort upcoming appointments (not completed)
        val upcomingAppointments = AppData.appointments
            .filter { it.status != "Completed" }
            .sortedBy { it.date } // If using ISO dates

        // Set up RecyclerView for upcoming appointments
        val upcomingRecycler = findViewById<RecyclerView>(R.id.recyclerHistory)
        val upcomingAdapter = HistoryAdapter(upcomingAppointments)
        upcomingRecycler.layoutManager = LinearLayoutManager(this)
        upcomingRecycler.adapter = upcomingAdapter
        upcomingRecycler.isNestedScrollingEnabled = false

        // Navigation Bar. Also used the same for other Activities.
        val navHome: Button = findViewById(R.id.navHome)
        val navBook: Button = findViewById(R.id.navBook)
        val navProfile: Button = findViewById(R.id.navProfile)

        navHome.setOnClickListener {
            // Does nothing.
        }
        navBook.setOnClickListener {
            startActivity(Intent(this, BookActivity::class.java))
        }
        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }


    }
}



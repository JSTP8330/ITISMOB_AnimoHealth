package com.itismob.s15.group6.mco2.animohealth

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*
import com.itismob.s15.group6.mco2.animohealth.model.Appointment
import com.itismob.s15.group6.mco2.animohealth.model.Certificate

class CheckInActivity : AppCompatActivity() {
    private var step = 0
    private lateinit var appointment: Appointment
    private lateinit var confirmedAppointments: List<Appointment>
    private lateinit var spinnerAdapter: ArrayAdapter<String>
    private var certificate: Certificate? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_check_in)
        AppData.initializeDemoData()

        val spinner = findViewById<Spinner>(R.id.confirmedAppointmentSpinner)
        val stepViews = listOf(
            findViewById<View>(R.id.stepQrLocation),
            findViewById<View>(R.id.stepChecklist),
            findViewById<View>(R.id.stepDone)
        )
        val prevButton = findViewById<Button>(R.id.prevButton)
        val nextButton = findViewById<Button>(R.id.nextButton)
        val appointmentWrapper = findViewById<View>(R.id.appointmentWrapper)
        val checklistLayout = findViewById<LinearLayout>(R.id.checkListItems)
        val progressBar = findViewById<ProgressBar>(R.id.progressBar)

        // Filter and sort confirmed via spinner
        confirmedAppointments = AppData.appointments
            .filter { it.status.equals("Confirmed", ignoreCase = true) }
            .sortedBy { it.date }

        spinnerAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            confirmedAppointments.map { "${it.title} (${it.date} ${it.time})" }
        )
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = spinnerAdapter

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                if (pos in confirmedAppointments.indices) {
                    appointment = confirmedAppointments[pos]
                    certificate = null
                    updateAppointmentCard()
                    updateCertificateCard()
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        // Set default appointment
        if (confirmedAppointments.isNotEmpty()) {
            spinner.setSelection(0)
            appointment = confirmedAppointments[0]
        } else {
            appointment = Appointment(-1, "No Confirmed Appointments", "", "", "", "")
        }

        // Get checklist

        fun getChecklistForTitle(title: String?): List<String> {
            return when (title?.lowercase()) {
                "annual check-up" -> listOf(
                    "Blood pressure measurement",
                    "Weight and height measurement",
                    "Visual acuity test",
                    "General health questionnaire",
                    "X-ray examination"
                )
                "dental check-up" -> listOf(
                    "Dental examination",
                    "Oral hygiene review",
                    "Oral prophylaxis",
                    "Cavity check"
                )
                "drug testing" -> listOf(
                    "Urine sample collection",
                    "Drug analysis",
                    "Review of results"
                )
                else -> listOf("General screening procedure")
            }
        }

        var checklist: List<String> = getChecklistForTitle(appointment.title)
        var checklistState: MutableList<Boolean> = checklist.map { false }.toMutableList()

        // Update UI based on step
        fun updateUi() {
            stepViews.forEachIndexed { i, v -> v.visibility = if (i == step) View.VISIBLE else View.GONE }
            prevButton.isEnabled = step > 0
            progressBar.progress = when (step) { 0 -> 33; 1 -> 66; else -> 100 }
            when (step) {
                0 -> {
                    nextButton.text = "Next"
                    appointmentWrapper.visibility = View.VISIBLE
                    nextButton.isEnabled = false
                }
                1 -> {
                    spinner.visibility = View.GONE
                    checklistLayout.removeAllViews()
                    checklist.forEachIndexed { i, item ->
                        val cb = CheckBox(this)
                        cb.text = item
                        cb.isChecked = checklistState[i]
                        cb.setOnCheckedChangeListener { _, checked ->
                            checklistState[i] = checked
                            nextButton.isEnabled = checklistState.all { it }
                        }
                        checklistLayout.addView(cb)
                    }
                    nextButton.text = "Next"
                    // Button to complete all checkboxes at once
                    findViewById<Button>(R.id.buttonCompleteChecklist).setOnClickListener {
                        for (i in 0 until checklistLayout.childCount) {
                            val view = checklistLayout.getChildAt(i)
                            if (view is CheckBox) {
                                view.isChecked = true
                            }
                        }
                        for (i in checklistState.indices) {
                            checklistState[i] = true
                        }
                        nextButton.isEnabled = true
                    }
                }
                2 -> {
                    spinner.visibility = View.GONE
                    appointmentWrapper.visibility = View.GONE
                    //Appointment update
                    if (appointment.status == "Confirmed") {
                        appointment.status = "Completed"
                    }
                    appointment.details = "All vitals normal."
                    //Certificate updates
                    if (certificate == null) certificate = generateCertificateFromAppointment(appointment)
                    updateCertificateCard()
                    nextButton.text = "Finish"
                    nextButton.isEnabled = true
                }
            }
            updateAppointmentCard()
            updateCertificateCard()
        }

        prevButton.setOnClickListener {
            if (step > 0) { step--; updateUi() }
        }
        nextButton.setOnClickListener {
            if (step == 0 && !nextButton.isEnabled) return@setOnClickListener
            if (step == 1 && !nextButton.isEnabled) return@setOnClickListener
            if (step < stepViews.size - 1) { step++; updateUi() } else { finish() }
        }

        findViewById<Button>(R.id.buttonScanQr).setOnClickListener {
            Toast.makeText(this, "QR scan successful!", Toast.LENGTH_SHORT).show()
            nextButton.isEnabled = true
        }
        findViewById<Button>(R.id.buttonScanLocation).setOnClickListener {
            Toast.makeText(this, "Location verified!", Toast.LENGTH_SHORT).show()
            nextButton.isEnabled = true
        }

        updateUi()
    }

    private fun generateCertificateFromAppointment(appt: Appointment): Certificate {
        val issuedDate = appt.date
        val expiryDate = addExpiryDate(issuedDate)
        val cert = Certificate(
            id = generateCertificateId(),
            title = appt.title,
            issuedDate = issuedDate,
            expiryDate = expiryDate,
            status = "Valid"
        )
        AppData.certificates.add(cert)
        return cert
    }

    private fun generateCertificateId(): Int {
        return (AppData.certificates.maxOfOrNull { it.id } ?: 0) + 1
    }

    private fun addExpiryDate(dateStr: String): String {
        val format = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val cal = Calendar.getInstance()
        try {
            cal.time = format.parse(dateStr)!!
            cal.add(Calendar.YEAR, 1)
            cal.add(Calendar.DAY_OF_YEAR, 14)
            return format.format(cal.time)
        } catch (e: Exception) {
            return dateStr
        }
    }

    private fun updateAppointmentCard() {
        findViewById<TextView>(R.id.appointmentTitle).text = appointment.title
        findViewById<TextView>(R.id.appointmentStatus).text =
            appointment.status.replaceFirstChar { it.uppercase() }
        findViewById<TextView>(R.id.appointmentDateTime).text =
            "${appointment.date} · ${appointment.time}"
        findViewById<TextView>(R.id.appointmentDetails).text = appointment.details
    }

    private fun updateCertificateCard() {
        findViewById<TextView>(R.id.certTitle).text = certificate?.title ?: ""
        findViewById<TextView>(R.id.certStatus).text = certificate?.status ?: ""
        findViewById<TextView>(R.id.certIssued).text =
            getString(R.string.certificate_issued, certificate?.issuedDate ?: "")
        findViewById<TextView>(R.id.certExpires).text =
            getString(R.string.certificate_expires, certificate?.expiryDate ?: "")
    }
}

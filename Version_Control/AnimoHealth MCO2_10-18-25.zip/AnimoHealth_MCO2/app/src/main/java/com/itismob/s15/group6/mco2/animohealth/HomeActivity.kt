package com.itismob.s15.group6.mco2.animohealth

import android.os.Bundle
import android.content.Intent
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // TODO: Dynamic user logic.

        val greetingText: TextView = findViewById(R.id.greetingText)
        greetingText.text = "Hi, test!"

        val bookNowButton: Button = findViewById(R.id.bookNowButton)
        bookNowButton.setOnClickListener {
            startActivity(Intent(this, BookActivity::class.java))
        }

        // TODO: Add more logic for stats, upcoming appointments.
        // TODO: Implement Check-In and Check-In Activity, as well as Calendar.

        // Navigation Bar. Also used the same for other Activities.

        val navHome: Button = findViewById(R.id.navHome)
        val navBook: Button = findViewById(R.id.navBook)
        val navProfile: Button = findViewById(R.id.navProfile)

        navHome.setOnClickListener {
            // Does nothing.
        }
        navBook.setOnClickListener {
            startActivity(Intent(this, BookActivity::class.java))
            finish()
        }
        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
            finish()
        }


    }
}



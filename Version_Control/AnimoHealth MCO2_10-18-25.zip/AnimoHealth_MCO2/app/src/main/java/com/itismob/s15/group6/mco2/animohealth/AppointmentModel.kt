package com.itismob.s15.group6.mco2.animohealth.model

data class Appointment(
    val title: String,
    val date: String,      // "2024-02-15"
    val time: String,      // "10:00 AM"
    val details: String,   // "All vitals normal. Recommended annual follow-up."
    val status: String     // "Completed", "Confirmed", or as needed
)

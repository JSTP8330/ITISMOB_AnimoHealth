package com.itismob.s15.group6.mco2.animohealth.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.itismob.s15.group6.mco2.animohealth.R
import com.itismob.s15.group6.mco2.animohealth.model.Certificate

class CertificateAdapter(private val items: List<Certificate>)
    : RecyclerView.Adapter<CertificateAdapter.CertViewHolder>() {

    class CertViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.certTitle)
        val issued: TextView = view.findViewById(R.id.certIssued)
        val expires: TextView = view.findViewById(R.id.certExpires)
        val status: TextView = view.findViewById(R.id.certStatus)
        val button: Button = view.findViewById(R.id.downloadButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CertViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_certificate, parent, false)
        return CertViewHolder(view)
    }

    override fun onBindViewHolder(holder: CertViewHolder, position: Int) {
        val cert = items[position]
        holder.title.text = cert.title
        holder.issued.text = "Issued: ${cert.issuedDate}"
        holder.expires.text = "Expires: ${cert.expiryDate}"
        holder.status.text = cert.status

        holder.button.setOnClickListener {
            Toast.makeText(it.context, "Download ${cert.title}", Toast.LENGTH_SHORT).show()
        }

        //Changes color based on status.
        holder.status.setTextColor(
            ContextCompat.getColor(holder.itemView.context, when (cert.status) {
                "Valid" -> R.color.green_200
                "Expiring Soon" -> R.color.red_200
                else -> R.color.black
            })
        )
    }

    override fun getItemCount(): Int = items.size
}

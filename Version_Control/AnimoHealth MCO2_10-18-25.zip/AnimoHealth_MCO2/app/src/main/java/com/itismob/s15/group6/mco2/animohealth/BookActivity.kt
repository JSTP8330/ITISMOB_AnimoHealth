package com.itismob.s15.group6.mco2.animohealth

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

import com.itismob.s15.group6.mco2.animohealth.model.Appointment

class BookActivity : AppCompatActivity() {
    private var step = 0
    //blank for now
    private val appointment = Appointment(
        title = "",
        date = "",
        time = "",
        details = "",
        status = ""
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_book)

        val stepViews = listOf(
            findViewById<LinearLayout>(R.id.stepType),
            findViewById<LinearLayout>(R.id.stepDate),
            findViewById<LinearLayout>(R.id.stepTime),
            findViewById<LinearLayout>(R.id.stepConfirm)
        )
        val prevButton: Button = findViewById(R.id.prevButton)
        val nextButton: Button = findViewById(R.id.nextButton)

        fun updateStepUi() {
            stepViews.forEachIndexed { idx, layout ->
                layout.visibility = if (idx == step) View.VISIBLE else View.GONE
            }
            prevButton.isEnabled = step > 0
            nextButton.text = if (step < stepViews.size - 1) "Next" else "Confirm"
        }

        prevButton.setOnClickListener {
            if (step > 0) step--
            updateStepUi()
        }
        nextButton.setOnClickListener {
            if (step < stepViews.size - 1) {
                step++
                updateStepUi()
            } else {
                // confirm booking, do something with 'appointment'
                Toast.makeText(this, "Appointment booked!", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, ProfileActivity::class.java))
                finish()
            }
        }

        updateStepUi()

        // Navigation Bar. Also used the same for other Activities.

        val navHome: Button = findViewById(R.id.navHome)
        val navBook: Button = findViewById(R.id.navBook)
        val navProfile: Button = findViewById(R.id.navProfile)

        navHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }
        navBook.setOnClickListener {
            // Does nothing.

        }
        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
            finish()
        }

    }
}

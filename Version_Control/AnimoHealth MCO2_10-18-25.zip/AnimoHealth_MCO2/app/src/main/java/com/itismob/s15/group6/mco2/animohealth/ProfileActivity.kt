package com.itismob.s15.group6.mco2.animohealth

import android.os.Bundle
import android.content.Intent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.itismob.s15.group6.mco2.animohealth.model.Appointment
import com.itismob.s15.group6.mco2.animohealth.model.Certificate

import com.itismob.s15.group6.mco2.animohealth.adapter.HistoryAdapter
import com.itismob.s15.group6.mco2.animohealth.adapter.CertificateAdapter

class ProfileActivity : AppCompatActivity() {

    //     Dummy data for demonstration
    private val historyList = listOf(
        Appointment("Annual Physical", "2024-02-15", "10:00 AM", "All vitals normal. Recommended annual follow-up.", "Completed"),
        Appointment("Drug Testing", "2024-01-20", "2:30 PM", "Test completed successfully.", "Confirmed"),
        Appointment("Dental Check-up", "2023-12-05", "11:00 AM", "Routine cleaning completed. No issues found.", "Completed")
    )

    private val certificateList = listOf(
        Certificate("Annual Physical", "2024-02-15", "2025-02-15", "Valid"),
        Certificate("Drug Testing", "2024-01-20", "2024-07-20", "Expiring Soon"),
        Certificate("Dental Check-up", "2023-09-10", "2025-09-10", "Valid")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val tabProfile: Button = findViewById(R.id.tabProfile)
        val tabCertificates: Button = findViewById(R.id.tabCertificates)
        val tabHistory: Button = findViewById(R.id.tabHistory)

        val sectionProfile: LinearLayout = findViewById(R.id.sectionProfile)
        val sectionCertificates: LinearLayout = findViewById(R.id.sectionCertificates)
        val sectionHistory: LinearLayout = findViewById(R.id.sectionHistory)

        tabProfile.setOnClickListener {
            sectionProfile.visibility = View.VISIBLE
            sectionCertificates.visibility = View.GONE
            sectionHistory.visibility = View.GONE
        }
        tabCertificates.setOnClickListener {
            sectionProfile.visibility = View.GONE
            sectionCertificates.visibility = View.VISIBLE
            sectionHistory.visibility = View.GONE
        }
        tabHistory.setOnClickListener {
            sectionProfile.visibility = View.GONE
            sectionCertificates.visibility = View.GONE
            sectionHistory.visibility = View.VISIBLE
        }

        // Set up RecyclerViews for certificates and history
        val recyclerCertificates: RecyclerView = findViewById(R.id.recyclerCertificates)
        recyclerCertificates.layoutManager = LinearLayoutManager(this)
        recyclerCertificates.adapter = CertificateAdapter(certificateList)

        val recyclerHistory: RecyclerView = findViewById(R.id.recyclerHistory)
        recyclerHistory.layoutManager = LinearLayoutManager(this)
        recyclerHistory.adapter = HistoryAdapter(historyList)

        // Navigation Bar. Also used the same for other Activities.

        val navHome: Button = findViewById(R.id.navHome)
        val navBook: Button = findViewById(R.id.navBook)
        val navProfile: Button = findViewById(R.id.navProfile)

        navHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }
        navBook.setOnClickListener {
            startActivity(Intent(this, BookActivity::class.java))
            finish()
        }
        navProfile.setOnClickListener {
            // Does nothing.
        }
    }
}
package com.itismob.s15.group6.mco2.animohealth.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.itismob.s15.group6.mco2.animohealth.R
import com.itismob.s15.group6.mco2.animohealth.model.Appointment

class HistoryAdapter(private val items: List<Appointment>)
    : RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder>() {

    class HistoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.appointmentTitle)
        val status: TextView = view.findViewById(R.id.appointmentStatus)
        val dateTime: TextView = view.findViewById(R.id.appointmentDateTime)
        val details: TextView = view.findViewById(R.id.appointmentDetails)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_appointment, parent, false)
        return HistoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        val appointment = items[position]
        holder.title.text = appointment.title
        holder.status.text = appointment.status
        holder.dateTime.text = "${appointment.date} · ${appointment.time}"
        holder.details.text = appointment.details

        //Changes color based on status.
        holder.status.setTextColor(
            ContextCompat.getColor(holder.itemView.context, when (appointment.status) {
                "Completed" -> R.color.green_200
                "Confirmed" -> R.color.blue_500
                else -> R.color.black
            })
        )
    }

    override fun getItemCount(): Int = items.size
}

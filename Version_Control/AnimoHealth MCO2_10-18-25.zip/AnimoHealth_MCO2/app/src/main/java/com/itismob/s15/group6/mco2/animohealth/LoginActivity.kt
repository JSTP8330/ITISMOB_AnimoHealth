package com.itismob.s15.group6.mco2.animohealth

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val emailEditText: EditText = findViewById(R.id.emailEditText)
        val passwordEditText: EditText = findViewById(R.id.passwordEditText)
        val signInButton: Button = findViewById(R.id.signInButton)
        val signUpText: TextView = findViewById(R.id.signUpText)

        signInButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString()
            if (!email.endsWith("@dlsu.edu.ph")) {
                Toast.makeText(this, "Please use your university email address", Toast.LENGTH_SHORT).show()
            } else {
                // TODO: Authenticate user credentials
                startActivity(Intent(this, HomeActivity::class.java))
                finish()
            }
        }

        signUpText.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }
}

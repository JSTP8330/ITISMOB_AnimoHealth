package com.itismob.s15.group6.mco2.animohealth

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore

object FirestoreHelper {

    private val db = FirebaseFirestore.getInstance()

    // Function to add a user to Firestore
    fun addUser(userId: String, name: String, email: String) {
        val user = hashMapOf(
            "name" to name,
            "email" to email
        )

        db.collection("users").document(userId)
            .set(user)
            .addOnSuccessListener {
                Log.d("FirestoreHelper", "User added successfully")
            }
            .addOnFailureListener { e ->
                Log.w("FirestoreHelper", "Error adding user", e)
            }
    }

    // Function to retrieve all users from Firestore
    fun getAllUsers() {
        db.collection("users")
            .get()
            .addOnSuccessListener { result ->
                for (document in result) {
                    Log.d("FirestoreHelper", "${document.id} => ${document.data}")
                }
            }
            .addOnFailureListener { e ->
                Log.w("FirestoreHelper", "Error getting users", e)
            }
    }
}

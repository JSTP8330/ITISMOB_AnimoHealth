package com.itismob.s15.group6.mco2.animohealth

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

class RegisterActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val nameEditText: EditText = findViewById(R.id.nameEditText)
        val studentIdEditText: EditText = findViewById(R.id.studentIdEditText)
        val emailEditText: EditText = findViewById(R.id.emailEditText)
        val passwordEditText: EditText = findViewById(R.id.passwordEditText)
        val confirmPasswordEditText: EditText = findViewById(R.id.confirmPasswordEditText)
        val birthdateEditText: EditText = findViewById(R.id.birthdateEditText)
        val genderSpinner: Spinner = findViewById(R.id.genderSpinner)
        val createAccountButton: Button = findViewById(R.id.createAccountButton)
        val signInText: TextView = findViewById(R.id.signInText)

        birthdateEditText.setOnClickListener {
            val defaultYear = 2000
            val defaultMonth = 0 // January (0-based)
            val defaultDay = 1
            val datePickerDialog =
                DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
                    val birthdateStr =
                        "%04d-%02d-%02d".format(selectedYear, selectedMonth + 1, selectedDay)
                    birthdateEditText.setText(birthdateStr)
                }, defaultYear, defaultMonth, defaultDay)
            datePickerDialog.show()
        }

        createAccountButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString()
            val confirmPassword = confirmPasswordEditText.text.toString()
            val name = nameEditText.text.toString()
            val studentId = studentIdEditText.text.toString()
            val birthdate = birthdateEditText.text.toString()
            val gender = genderSpinner.selectedItem.toString()

            when {
                !email.endsWith("@dlsu.edu.ph") ->
                    Toast.makeText(this, "Please use your university email address", Toast.LENGTH_SHORT).show()
                (password != confirmPassword) ->
                    Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
                (password.length < 5) ->
                    Toast.makeText(this, "Password must be at least 5 characters", Toast.LENGTH_SHORT).show()
                else -> {
                    val newUser = hashMapOf(
                        "email" to email,
                        "password" to password,
                        "name" to name,
                        "studentId" to studentId,
                        "birthDate" to birthdate,
                        "gender" to gender,
                        "phoneNumber" to "not set",
                        "emergencyNumber" to "not set"
                    )

                    db.collection("users").add(newUser)
                        .addOnSuccessListener {
                            Toast.makeText(this, "Account created! Please sign in.", Toast.LENGTH_SHORT).show()
                            startActivity(Intent(this, LoginActivity::class.java))
                            finish()
                        }
                        .addOnFailureListener { e ->
                            Toast.makeText(this, "Error creating account: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                }
            }
        }
        signInText.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}

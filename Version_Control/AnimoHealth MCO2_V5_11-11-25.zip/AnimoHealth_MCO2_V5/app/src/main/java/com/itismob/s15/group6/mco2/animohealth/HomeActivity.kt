package com.itismob.s15.group6.mco2.animohealth

import android.annotation.SuppressLint
import android.os.Bundle
import android.content.Intent
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.itismob.s15.group6.mco2.animohealth.adapter.HistoryAdapter
import com.itismob.s15.group6.mco2.animohealth.utils.SharedPrefsHelper
import com.itismob.s15.group6.mco2.animohealth.FirestoreHelper

class HomeActivity : AppCompatActivity() {

    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Get current user data
        val userId = SharedPrefsHelper.getCurrentUserId(this) ?: return
        Log.d("HomeActivity", "Current userId: $userId")

        // Set the greeting text
        val greetingText: TextView = findViewById(R.id.greetingText)

        // Load user info from Firestore
        FirestoreHelper.getUser(userId) { userData ->
            if (userData != null) {
                val name = userData["name"] as? String ?: "User"
                val firstName = name.trim().split(" ").firstOrNull()?.replaceFirstChar { it.uppercase() } ?: "User"
                greetingText.text = "Hi, $firstName!"
            }
        }

        // Buttons
        val bookNowButton: Button = findViewById(R.id.bookNowButton)
        bookNowButton.setOnClickListener {
            startActivity(Intent(this, BookActivity::class.java))
            finish()
        }

        val checkInButton: Button = findViewById(R.id.checkInButton)
        checkInButton.setOnClickListener {
            startActivity(Intent(this, CheckInActivity::class.java))
            finish()
        }

        // Appointment Stats from Firestore
        FirestoreHelper.getAppointments(userId) { appointments ->

            Log.d("HomeActivity", "Fetched appointments: ${appointments.size}")
            for (apt in appointments) {
                Log.d("HomeActivity", "Appointment: ${apt.title}, status: ${apt.status}, userId: ${apt.userIdApp}")
            }

            val totalAppointments = findViewById<TextView>(R.id.statsTotalAppointments)
            val completedAppointments = findViewById<TextView>(R.id.statsCompletedAppointments)

            totalAppointments.text = "${appointments.size}"
            completedAppointments.text = "${appointments.count { it.status == "Completed" }}"

            // Upcoming Appointments List
            val upcomingAppointments = appointments
                .filter { it.status != "Completed" }
                .sortedBy { it.date }

            val upcomingRecycler = findViewById<RecyclerView>(R.id.recyclerHistory)
            val upcomingAdapter = HistoryAdapter(upcomingAppointments)
            upcomingRecycler.layoutManager = LinearLayoutManager(this)
            upcomingRecycler.adapter = upcomingAdapter
            upcomingRecycler.isNestedScrollingEnabled = false
        }

        // Bottom Navigation
        val navHome: Button = findViewById(R.id.navHome)
        val navBook: Button = findViewById(R.id.navBook)
        val navProfile: Button = findViewById(R.id.navProfile)

        navHome.setOnClickListener {
            // Stay on home
        }

        navBook.setOnClickListener {
            startActivity(Intent(this, BookActivity::class.java))
            finish()
        }

        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
            finish()
        }
    }
}

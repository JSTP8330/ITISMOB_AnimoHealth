package com.itismob.s15.group6.mco2.animohealth

import android.annotation.SuppressLint
import android.os.Bundle
import android.content.Intent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.itismob.s15.group6.mco2.animohealth.adapter.HistoryAdapter
import com.itismob.s15.group6.mco2.animohealth.adapter.CertificateAdapter
import com.itismob.s15.group6.mco2.animohealth.utils.SharedPrefsHelper

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val userId = SharedPrefsHelper.getCurrentUserId(this) ?: return

        val tabProfile: Button = findViewById(R.id.tabProfile)
        val tabCertificates: Button = findViewById(R.id.tabCertificates)
        val tabHistory: Button = findViewById(R.id.tabHistory)

        val sectionProfile: LinearLayout = findViewById(R.id.sectionProfile)
        val sectionCertificates: LinearLayout = findViewById(R.id.sectionCertificates)
        val sectionHistory: LinearLayout = findViewById(R.id.sectionHistory)


        // User editing functions. To be refined/bug-fixed for later.

        //        // Get references to all views
        //        val nameTV = findViewById<TextView>(R.id.textFullName)
        //        val nameET = findViewById<EditText>(R.id.editFullName)
        //        val studentIdTV = findViewById<TextView>(R.id.textStudentId)
        //        val studentIdET = findViewById<EditText>(R.id.editStudentId)
        //        val emailTV = findViewById<TextView>(R.id.textEmail)
        //        val emailET = findViewById<EditText>(R.id.editEmail)
        //        val phoneTV = findViewById<TextView>(R.id.textPhone)
        //        val phoneET = findViewById<EditText>(R.id.editPhone)
        //        val birthTV = findViewById<TextView>(R.id.textBirthDate)
        //        val birthET = findViewById<EditText>(R.id.editBirthDate)
        //        val emergencyTV = findViewById<TextView>(R.id.textEmergencyContact)
        //        val emergencyET = findViewById<EditText>(R.id.editEmergencyContact)
        //        val editButton = findViewById<Button>(R.id.buttonEditInformation)
        //        val saveButton = findViewById<Button>(R.id.buttonSaveInformation)
        //
        //        // Load user info into UI fields
        //        @SuppressLint("SetTextI18n")
        //        fun loadUserData() {
        //            user?.let { currentUser ->
        //                nameTV.text = "Full Name: ${currentUser.name}"
        //                nameET.setText(currentUser.name)
        //                studentIdTV.text = "Student ID: ${currentUser.studentId}"
        //                studentIdET.setText(currentUser.studentId)
        //                emailTV.text = "Email: ${currentUser.email}"
        //                emailET.setText(currentUser.email)
        //                phoneTV.text = "Phone: ${currentUser.phoneNumber}"
        //                phoneET.setText(currentUser.phoneNumber)
        //                birthTV.text = "Date of Birth: ${currentUser.birthDate}"
        //                birthET.setText(currentUser.birthDate)
        //                emergencyTV.text = "Emergency Contact: ${currentUser.emergencyNumber}"
        //                emergencyET.setText(currentUser.emergencyNumber)
        //            }
        //        }
        //
        //
        //        // Toggle between view/edit mode
        //        fun setEditMode(enabled: Boolean) {
        //            nameTV.visibility = if (enabled) View.GONE else View.VISIBLE
        //            nameET.visibility = if (enabled) View.VISIBLE else View.GONE
        //            studentIdTV.visibility = if (enabled) View.GONE else View.VISIBLE
        //            studentIdET.visibility = if (enabled) View.VISIBLE else View.GONE
        //            emailTV.visibility = if (enabled) View.GONE else View.VISIBLE
        //            emailET.visibility = if (enabled) View.VISIBLE else View.GONE
        //            phoneTV.visibility = if (enabled) View.GONE else View.VISIBLE
        //            phoneET.visibility = if (enabled) View.VISIBLE else View.GONE
        //            birthTV.visibility = if (enabled) View.GONE else View.VISIBLE
        //            birthET.visibility = if (enabled) View.VISIBLE else View.GONE
        //            emergencyTV.visibility = if (enabled) View.GONE else View.VISIBLE
        //            emergencyET.visibility = if (enabled) View.VISIBLE else View.GONE
        //            editButton.visibility = if (enabled) View.GONE else View.VISIBLE
        //            saveButton.visibility = if (enabled) View.VISIBLE else View.GONE
        //        }
        //
        //        editButton.setOnClickListener { setEditMode(true) }
        //        saveButton.setOnClickListener {
        //            user?.name = nameET.text.toString()
        //            user?.studentId = studentIdET.text.toString()
        //            user?.email = emailET.text.toString()
        //            user?.phoneNumber = phoneET.text.toString()
        //            user?.birthDate = birthET.text.toString()
        //            user?.emergencyNumber = emergencyET.text.toString()
        //            loadUserData()
        //            setEditMode(false)
        //            Toast.makeText(this, "Information updated!", Toast.LENGTH_SHORT).show()
        //        }

        // Visibility of sections based on tab selection
        tabProfile.performClick() // Show profile by default

        findViewById<Button>(R.id.buttonLogout).setOnClickListener {
            SharedPrefsHelper.logOut(this)
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        tabProfile.setOnClickListener {
            sectionProfile.visibility = View.VISIBLE
            sectionCertificates.visibility = View.GONE
            sectionHistory.visibility = View.GONE
        }

        tabCertificates.setOnClickListener {
            sectionProfile.visibility = View.GONE
            sectionCertificates.visibility = View.VISIBLE
            sectionHistory.visibility = View.GONE

            // Load certificates from Firestore
            FirestoreHelper.getCertificates(userId) { certificates ->
                val recyclerCertificates: RecyclerView = findViewById(R.id.recyclerCertificates)
                recyclerCertificates.layoutManager = LinearLayoutManager(this)
                recyclerCertificates.adapter = CertificateAdapter(certificates)
            }
        }

        tabHistory.setOnClickListener {
            sectionProfile.visibility = View.GONE
            sectionCertificates.visibility = View.GONE
            sectionHistory.visibility = View.VISIBLE

            // Load appointments from Firestore
            FirestoreHelper.getAppointments(userId) { appointments ->
                val recyclerHistory: RecyclerView = findViewById(R.id.recyclerHistory)
                recyclerHistory.layoutManager = LinearLayoutManager(this)
                recyclerHistory.adapter = HistoryAdapter(appointments)
            }
        }

        // Navigation Bar
        val navHome: Button = findViewById(R.id.navHome)
        val navBook: Button = findViewById(R.id.navBook)
        val navProfile: Button = findViewById(R.id.navProfile)

        navHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        navBook.setOnClickListener {
            startActivity(Intent(this, BookActivity::class.java))
            finish()
        }

        navProfile.setOnClickListener {
            // Stay on Profile
        }
    }
}

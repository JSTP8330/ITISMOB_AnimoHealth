package com.itismob.s15.group6.mco2.animohealth

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import com.itismob.s15.group6.mco2.animohealth.FirestoreHelper
import com.itismob.s15.group6.mco2.animohealth.model.Appointment
import com.itismob.s15.group6.mco2.animohealth.utils.SharedPrefsHelper

class BookActivity : AppCompatActivity() {

    private var step = 0
    private var backPressedOnce = false
    private val backPressResetRunnable = Runnable { backPressedOnce = false }
    private var appointmentTitle: String? = null
    private var appointmentDate: String? = null
    private var appointmentDateHuman: String? = null
    private var appointmentTime: String? = null

    //slot verification
    private fun checkSlotAvailability(selectedDate: String, selectedTime: String, userId: String, callback: (Boolean, String) -> Unit) {
        FirestoreHelper.getAllAppointments { allAppointments ->
            // filter appointments on the same date with time conflict (Confirmed or Completed status)
            val bookedSlots = allAppointments.filter { apt ->
                apt.date == selectedDate &&
                        (apt.status.equals("Confirmed", ignoreCase = true) ||
                                apt.status.equals("Completed", ignoreCase = true)) &&
                        isTimeConflict(selectedTime, apt.time)
            }

            // count total appointments in the conflicting time slot
            val totalInSlot = bookedSlots.size

            // get distinct user IDs booking in that time slot
            val usersInSlot = bookedSlots.map { it.userIdApp }.distinct()

            // check constraint 1: Only one distinct user per slot
            if (usersInSlot.isNotEmpty() && usersInSlot.contains(userId)) {
                // same user trying to book again in same slot
                callback(false, "You already have an appointment at $selectedTime on $selectedDate")
                return@getAllAppointments
            }

            //check constraint 2: Only one user per slot
            if (usersInSlot.isNotEmpty() && usersInSlot.first() != userId) {
                // different user already booked this slot
                callback(false, "Time slot $selectedTime is reserved for another user. Please choose a different time.")
                return@getAllAppointments
            }

            // All constraints passed
            callback(true, "Time slot is available! (${totalInSlot}/5 appointments)")
        }
    }


    private fun isTimeConflict(requestedTime: String, bookedTime: String): Boolean {
        val requestedMinutes = convertTimeToMinutes(requestedTime)
        val bookedMinutes = convertTimeToMinutes(bookedTime)
        val APPOINTMENT_DURATION_MINUTES = 30
        val requestedEnd = requestedMinutes + APPOINTMENT_DURATION_MINUTES
        val bookedEnd = bookedMinutes + APPOINTMENT_DURATION_MINUTES
        return requestedMinutes < bookedEnd && requestedEnd > bookedMinutes
    }

    private fun convertTimeToMinutes(timeString: String): Int {
        return try {
            val parts = timeString.trim().split(":| ".toRegex())
            var hour = parts[0].toInt()
            val minute = parts[1].toInt()

            if (timeString.contains("PM", ignoreCase = true) && hour != 12) {
                hour += 12
            } else if (timeString.contains("AM", ignoreCase = true) && hour == 12) {
                hour = 0
            }

            hour * 60 + minute
        } catch (e: Exception) {
            0
        }
    }



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_book)

        val stepViews = listOf(
            findViewById<LinearLayout>(R.id.stepType),
            findViewById<LinearLayout>(R.id.stepDate),
            findViewById<LinearLayout>(R.id.stepTime),
            findViewById<LinearLayout>(R.id.stepConfirm)
        )

        val prevButton = findViewById<Button>(R.id.prevButton)
        val nextButton = findViewById<Button>(R.id.nextButton)

        // Appointment Type buttons
        val typeButtons = mapOf(
            R.id.typePhysical to "Annual Check-up",
            R.id.typeDental to "Dental Check-up",
            R.id.typeDrug to "Drug Testing"
        )

        typeButtons.forEach { (id, title) ->
            findViewById<Button>(id).setOnClickListener {
                appointmentTitle = title
                nextStep(stepViews, prevButton, nextButton)
            }
        }

        // Date Step
        val calendar = findViewById<CalendarView>(R.id.calendarDatePicker)
        val selectedDateView = findViewById<TextView>(R.id.selectedDate)
        val today = Calendar.getInstance()
        calendar.minDate = today.timeInMillis // Disallow past dates

        calendar.setOnDateChangeListener { _, year, month, dayOfMonth ->
            val selectedCal = Calendar.getInstance().apply { set(year, month, dayOfMonth) }
            if (selectedCal.before(today)) {
                Toast.makeText(this, "Cannot book for today or a past date.", Toast.LENGTH_SHORT).show()
                appointmentDate = null
                selectedDateView.text = "No date selected"
            } else {
                appointmentDate = "%04d-%02d-%02d".format(year, month + 1, dayOfMonth)
                val monthName = SimpleDateFormat("MMMM", Locale.getDefault()).format(selectedCal.time)
                appointmentDateHuman = "$monthName $dayOfMonth, $year"
                selectedDateView.text = "The date of the appointment is $appointmentDateHuman."
            }
        }

        // Time Step
        val timeSlots = mapOf(
            R.id.time0900 to "09:00",
            R.id.time0930 to "09:30",
            R.id.time1000 to "10:00",
            R.id.time1030 to "10:30",
            R.id.time1100 to "11:00",
            R.id.time1130 to "11:30",
            R.id.time1200 to "12:00",
            R.id.time1300 to "13:00"
        )

        val selectedTimeView = findViewById<TextView>(R.id.selectedTime)

        timeSlots.forEach { (id, time) ->
            findViewById<Button>(id).setOnClickListener {
                val hour = time.substringBefore(":").toInt()
                val period = if (hour >= 12) "PM" else "AM"
                val displayHour = if (hour > 12) hour - 12 else if (hour == 0) 12 else hour
                val displayTime = "$displayHour:${time.substringAfter(":")} $period"

                if (appointmentDate != null) {
                    val userId = SharedPrefsHelper.getCurrentUserId(this@BookActivity) ?: return@setOnClickListener

                    checkSlotAvailability(appointmentDate!!, displayTime, userId) { isAvailable, message ->
                        if (isAvailable) {
                            // Slot is available - allow booking
                            appointmentTime = displayTime
                            selectedTimeView.text = "The time of the appointment is $appointmentTime."
                            selectedTimeView.setTextColor(android.graphics.Color.GREEN)
                            nextButton.isEnabled = true
                            Log.d("BookActivity", "Slot available: $message")
                        } else {
                            // Slot is taken or violates constraints - block booking
                            appointmentTime = null
                            selectedTimeView.text = message
                            selectedTimeView.setTextColor(android.graphics.Color.RED)
                            nextButton.isEnabled = false
                            Toast.makeText(this@BookActivity, message, Toast.LENGTH_LONG).show()
                            Log.w("BookActivity", "Slot unavailable: $message")
                        }
                    }
                } else {
                    Toast.makeText(this@BookActivity, "Please select a date first", Toast.LENGTH_SHORT).show()
                }
            }
        }



        // Confirmation summary update
        fun updateConfirmationSummary() {
            findViewById<TextView>(R.id.summaryType).text = "Type: ${appointmentTitle ?: ""}"
            findViewById<TextView>(R.id.summaryDate).text = "Date: ${appointmentDate ?: ""}"
            findViewById<TextView>(R.id.summaryTime).text = "Time: ${appointmentTime ?: ""}"
        }

        fun updateStepUi() {
            stepViews.forEachIndexed { idx, layout ->
                layout.visibility = if (idx == step) View.VISIBLE else View.GONE
            }
            prevButton.isEnabled = step > 0
            nextButton.text = if (step < stepViews.size - 1) "Next" else "Confirm"
            if (step == 3) updateConfirmationSummary()
        }

        prevButton.setOnClickListener {
            if (step > 0) {
                step--
                updateStepUi()
            }
        }

        nextButton.setOnClickListener {
            when (step) {
                0 -> {
                    if (appointmentTitle.isNullOrEmpty()) {
                        Toast.makeText(this, "Select an appointment type", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    step++
                    updateStepUi()
                }
                1 -> {
                    if (appointmentDate.isNullOrEmpty()) {
                        Toast.makeText(this, "Select a date", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    step++
                    updateStepUi()
                }
                2 -> {
                    if (appointmentTime.isNullOrEmpty()) {
                        Toast.makeText(this, "Select a time slot", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    step++
                    updateStepUi()
                }
                3 -> {
                    val userId = SharedPrefsHelper.getCurrentUserId(this)
                    if (userId != null) {
                        val newAppointment = Appointment(
                            id = generateAppointmentId(),
                            title = appointmentTitle ?: "",
                            date = appointmentDate ?: "",
                            time = appointmentTime ?: "",
                            details = "Date and time confirmed.",
                            status = "Confirmed",
                            userIdApp = userId
                        )

                        // Save to Firestore
                        FirestoreHelper.addAppointment(userId, newAppointment) { appointmentId ->
                            if (appointmentId != null) {
                                Toast.makeText(this, "Appointment booked!", Toast.LENGTH_SHORT).show()
                                startActivity(Intent(this, ProfileActivity::class.java))
                                finish()
                            } else {
                                Toast.makeText(this, "Failed to book appointment", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            }
        }

        updateStepUi()
    }

    private fun nextStep(
        stepViews: List<LinearLayout>,
        prevButton: Button,
        nextButton: Button
    ) {
        if (step < stepViews.size - 1) {
            step++
            stepViews.forEachIndexed { idx, layout ->
                layout.visibility = if (idx == step) View.VISIBLE else View.GONE
            }
            prevButton.isEnabled = step > 0
            nextButton.text = if (step < stepViews.size - 1) "Next" else "Confirm"
        }
    }

    @SuppressLint("GestureBackNavigation")
    override fun onBackPressed() {
        if (step > 0) {
            step--
            findViewById<Button>(R.id.prevButton).performClick()
            return
        }

        if (backPressedOnce) {
            super.onBackPressed()
            val intent = Intent(this, HomeActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
            return
        }

        backPressedOnce = true
        Toast.makeText(this, "Press back again to go home", Toast.LENGTH_SHORT).show()

        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(backPressResetRunnable, 2000)
    }

    private fun generateAppointmentId(): String {
        return System.currentTimeMillis().toString()  // String ID
    }
}

package com.itismob.s15.group6.mco2.animohealth
import com.itismob.s15.group6.mco2.animohealth.utils.SharedPrefsHelper
import com.google.firebase.firestore.FirebaseFirestore

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_login)

        val emailEditText: EditText = findViewById(R.id.emailEditText)
        val passwordEditText: EditText = findViewById(R.id.passwordEditText)
        val signInButton: Button = findViewById(R.id.signInButton)
        val signUpText: TextView = findViewById(R.id.signUpText)

        signInButton.setOnClickListener {
            val email = emailEditText.text.toString().trim().lowercase()
            val password = passwordEditText.text.toString()

            if (!email.endsWith("@dlsu.edu.ph")) {
                Toast.makeText(this, "Please use your university email address", Toast.LENGTH_SHORT).show()
            } else {
                db.collection("users")
                    .whereEqualTo("email", email)
                    .get()
                    .addOnSuccessListener { documents ->
                        if (!documents.isEmpty) {
                            val user = documents.first()
                            val storedPassword = user.getString("password")

                            if (storedPassword == password) {
                                SharedPrefsHelper.setLoggedIn(this, true)
                                val userId = user.id
                                SharedPrefsHelper.setCurrentUserId(this, userId)
                                startActivity(Intent(this, HomeActivity::class.java))
                                finish()
                            } else {
                                Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            Toast.makeText(this, "Account not found", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(this, "Error logging in: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
            }
        }

        signUpText.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }
}

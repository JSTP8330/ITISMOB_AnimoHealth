package com.itismob.s15.group6.mco2.animohealth

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.itismob.s15.group6.mco2.animohealth.utils.SharedPrefsHelper
import java.util.Calendar
import android.app.DatePickerDialog

class RegisterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val nameEditText: EditText = findViewById(R.id.nameEditText)
        val emailEditText: EditText = findViewById(R.id.emailEditText)
        val passwordEditText: EditText = findViewById(R.id.passwordEditText)
        val confirmPasswordEditText: EditText = findViewById(R.id.confirmPasswordEditText)
        val birthdateEditText: EditText = findViewById(R.id.birthdateEditText)
        val createAccountButton: Button = findViewById(R.id.createAccountButton)
        val signInText: android.widget.TextView = findViewById(R.id.signInText)

        birthdateEditText.setOnClickListener {
            val calendar = Calendar.getInstance()
            DatePickerDialog(
                this,
                { _, year, month, day ->
                    birthdateEditText.setText("$year-${month + 1}-$day")
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        createAccountButton.setOnClickListener {
            val name = nameEditText.text.toString().trim()
            val email = emailEditText.text.toString().trim().lowercase()
            val password = passwordEditText.text.toString()
            val confirmPassword = confirmPasswordEditText.text.toString()
            val birthdate = birthdateEditText.text.toString()

            when {
                name.isEmpty() -> Toast.makeText(this, "Please enter your name", Toast.LENGTH_SHORT).show()
                !email.endsWith("@dlsu.edu.ph") -> Toast.makeText(this, "Please use your DLSU email", Toast.LENGTH_SHORT).show()
                password.isEmpty() || password.length < 6 -> Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
                password != confirmPassword -> Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
                birthdate.isEmpty() -> Toast.makeText(this, "Please enter your birthdate", Toast.LENGTH_SHORT).show()
                else -> {
                    // Register user in Firestore
                    FirestoreHelper.addUser(email, name, email) { success ->
                        if (success) {
                            Toast.makeText(this, "Registration successful! Please login.", Toast.LENGTH_SHORT).show()
                            startActivity(Intent(this, LoginActivity::class.java))
                            finish()
                        } else {
                            Toast.makeText(this, "Registration failed. Please try again.", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }

        signInText.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}

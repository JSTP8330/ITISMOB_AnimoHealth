package com.itismob.s15.group6.mco2.animohealth

import android.annotation.SuppressLint
import android.os.Bundle
import android.content.Intent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.Toast
import android.widget.TextView
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.itismob.s15.group6.mco2.animohealth.adapter.HistoryAdapter
import com.itismob.s15.group6.mco2.animohealth.adapter.CertificateAdapter
import com.itismob.s15.group6.mco2.animohealth.utils.SharedPrefsHelper
import com.google.firebase.auth.FirebaseAuth

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val userId = SharedPrefsHelper.getCurrentUserId(this) ?: return

        // Tab buttons
        val tabProfile: Button = findViewById(R.id.tabProfile)
        val tabCertificates: Button = findViewById(R.id.tabCertificates)
        val tabHistory: Button = findViewById(R.id.tabHistory)

        // Sections
        val sectionProfile: LinearLayout = findViewById(R.id.sectionProfile)
        val sectionCertificates: LinearLayout = findViewById(R.id.sectionCertificates)
        val sectionHistory: LinearLayout = findViewById(R.id.sectionHistory)

        // Profile view references
        val nameTV = findViewById<TextView>(R.id.textFullName)
        val nameET = findViewById<EditText>(R.id.editFullName)
        val studentIdTV = findViewById<TextView>(R.id.textStudentId)
        val studentIdET = findViewById<EditText>(R.id.editStudentId)
        val emailTV = findViewById<TextView>(R.id.textEmail)
        val emailET = findViewById<EditText>(R.id.editEmail)
        val phoneTV = findViewById<TextView>(R.id.textPhone)
        val phoneET = findViewById<EditText>(R.id.editPhone)
        val birthTV = findViewById<TextView>(R.id.textBirthDate)
        val birthET = findViewById<EditText>(R.id.editBirthDate)
        val emergencyTV = findViewById<TextView>(R.id.textEmergencyContact)
        val emergencyET = findViewById<EditText>(R.id.editEmergencyContact)
        val genderSpinner = findViewById<Spinner>(R.id.genderSpinner)
        val genderSpinnerDisplay = findViewById<TextView>(R.id.genderSpinnerDisplay)
        val genderOptions = resources.getStringArray(R.array.gender_options)
        val editButton = findViewById<Button>(R.id.buttonEditInformation)
        val saveButton = findViewById<Button>(R.id.buttonSaveInformation)

        // Load user data from Firestore
        fun loadUserData() {
            FirestoreHelper.getUser(userId) { userMap ->
                userMap?.let { user ->
                    nameTV.text = "Full Name: ${user["name"] ?: ""}"
                    nameET.setText(user["name"]?.toString() ?: "")
                    studentIdTV.text = "Student ID: ${user["studentId"] ?: ""}"
                    studentIdET.setText(user["studentId"]?.toString() ?: "")
                    emailTV.text = "Email: ${user["email"] ?: ""}"
                    emailET.setText(user["email"]?.toString() ?: "")
                    phoneTV.text = "Phone: ${user["phoneNumber"] ?: ""}"
                    phoneET.setText(user["phoneNumber"]?.toString() ?: "")
                    birthTV.text = "Date of Birth: ${user["birthDate"] ?: ""}"
                    birthET.setText(user["birthDate"]?.toString() ?: "")
                    emergencyTV.text = "Emergency Contact: ${user["emergencyNumber"] ?: ""}"
                    emergencyET.setText(user["emergencyNumber"]?.toString() ?: "")
                    genderSpinnerDisplay.text = "Gender: ${user["gender"] ?: ""}"
                    genderSpinnerDisplay.visibility = View.VISIBLE
                    val currentGender = user["gender"]?.toString() ?: ""
                    val genderIndex = genderOptions.indexOf(currentGender)
                    genderSpinner.setSelection(if (genderIndex >= 0) genderIndex else 0)
                }
            }
        }

        // Toggle edit mode
        fun setEditMode(enabled: Boolean) {
            nameTV.visibility = if (enabled) View.GONE else View.VISIBLE
            nameET.visibility = if (enabled) View.VISIBLE else View.GONE
            studentIdTV.visibility = if (enabled) View.GONE else View.VISIBLE
            studentIdET.visibility = if (enabled) View.VISIBLE else View.GONE
            emailTV.visibility = if (enabled) View.GONE else View.VISIBLE
            emailET.visibility = if (enabled) View.VISIBLE else View.GONE
            phoneTV.visibility = if (enabled) View.GONE else View.VISIBLE
            phoneET.visibility = if (enabled) View.VISIBLE else View.GONE
            birthTV.visibility = if (enabled) View.GONE else View.VISIBLE
            birthET.visibility = if (enabled) View.VISIBLE else View.GONE
            emergencyTV.visibility = if (enabled) View.GONE else View.VISIBLE
            emergencyET.visibility = if (enabled) View.VISIBLE else View.GONE
            genderSpinnerDisplay.visibility = if (enabled) View.GONE else View.VISIBLE
            genderSpinner.visibility = if (enabled) View.VISIBLE else View.GONE
            genderSpinner.isEnabled = enabled
            editButton.visibility = if (enabled) View.GONE else View.VISIBLE
            saveButton.visibility = if (enabled) View.VISIBLE else View.GONE
        }

        // Initialize UI
        loadUserData()
        setEditMode(false)

        // Edit button listener
        editButton.setOnClickListener {
            setEditMode(true)
        }

        // Save button listener
        saveButton.setOnClickListener {
            val updates = mapOf(
                "name" to nameET.text.toString(),
                "studentId" to studentIdET.text.toString(),
                "email" to emailET.text.toString(),
                "phoneNumber" to phoneET.text.toString(),
                "birthDate" to birthET.text.toString(),
                "emergencyNumber" to emergencyET.text.toString(),
                "gender" to genderSpinner.selectedItem.toString()
            )

            FirestoreHelper.updateUser(userId, updates) { success ->
                if (success) {
                    loadUserData() // Refresh from Firestore
                    setEditMode(false)
                    Toast.makeText(this, "Information updated!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Failed to update information", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // Visibility of sections based on tab selection
        tabProfile.performClick() // Show profile by default

        findViewById<Button>(R.id.buttonLogout).setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            SharedPrefsHelper.logOut(this)
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        tabProfile.setOnClickListener {
            sectionProfile.visibility = View.VISIBLE
            sectionCertificates.visibility = View.GONE
            sectionHistory.visibility = View.GONE
        }

        tabCertificates.setOnClickListener {
            sectionProfile.visibility = View.GONE
            sectionCertificates.visibility = View.VISIBLE
            sectionHistory.visibility = View.GONE

            // Load certificates from Firestore
            FirestoreHelper.getCertificates(userId) { certificates ->
                val recyclerCertificates: RecyclerView = findViewById(R.id.recyclerCertificates)
                recyclerCertificates.layoutManager = LinearLayoutManager(this)
                recyclerCertificates.adapter = CertificateAdapter(certificates)
            }
        }

        tabHistory.setOnClickListener {
            sectionProfile.visibility = View.GONE
            sectionCertificates.visibility = View.GONE
            sectionHistory.visibility = View.VISIBLE

            // Load appointments from Firestore
            FirestoreHelper.getAppointments(userId) { appointments ->
                val recyclerHistory: RecyclerView = findViewById(R.id.recyclerHistory)
                recyclerHistory.layoutManager = LinearLayoutManager(this)
                // Pass true to show delete button in Profile/History
                recyclerHistory.adapter = HistoryAdapter(appointments.toMutableList(), showDeleteButton = true)
            }
        }

        // Navigation Bar
        val navHome: Button = findViewById(R.id.navHome)
        val navBook: Button = findViewById(R.id.navBook)
        val navProfile: Button = findViewById(R.id.navProfile)

        navHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        navBook.setOnClickListener {
            startActivity(Intent(this, BookActivity::class.java))
            finish()
        }

        navProfile.setOnClickListener {
            // Stay on Profile
        }
    }
}

package com.itismob.s15.group6.mco2.animohealth.model

data class Appointment(
    val id: String,
    val title: String,
    val date: String,      // "2024-02-15"
    val time: String,      // "10:00 AM"
    var details: String,   // "All vitals normal. Recommended annual follow-up."
    var status: String,     // "Completed", "Confirmed", "Incomplete", or as needed
    var userIdApp: String  // User ID of the user who booked the appointment
)

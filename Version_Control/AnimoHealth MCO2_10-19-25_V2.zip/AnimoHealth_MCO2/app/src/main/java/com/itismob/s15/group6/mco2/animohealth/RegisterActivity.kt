package com.itismob.s15.group6.mco2.animohealth

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.itismob.s15.group6.mco2.animohealth.model.User

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val nameEditText: EditText = findViewById(R.id.nameEditText)
        val studentIdEditText: EditText = findViewById(R.id.studentIdEditText)
        val emailEditText: EditText = findViewById(R.id.emailEditText)
        val passwordEditText: EditText = findViewById(R.id.passwordEditText)
        val confirmPasswordEditText: EditText = findViewById(R.id.confirmPasswordEditText)
        val createAccountButton: Button = findViewById(R.id.createAccountButton)
        val signInText: TextView = findViewById(R.id.signInText)

        createAccountButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString()
            val confirmPassword = confirmPasswordEditText.text.toString()
            val name = nameEditText.text.toString()
            val studentId = studentIdEditText.text.toString()

            when {
                !email.endsWith("@dlsu.edu.ph") ->
                    Toast.makeText(this, "Please use your university email address", Toast.LENGTH_SHORT).show()
                (password != confirmPassword) ->
                    Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
                (password.length < 6) ->
                    Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
                (AppData.users.any { it.email.equals(email, ignoreCase = true) }) ->
                    Toast.makeText(this, "Account already exists for this email", Toast.LENGTH_SHORT).show()
                else -> {
                    val newUser = User(
                        id = (AppData.users.maxOfOrNull { it.id } ?: 0) + 1,
                        email = email,
                        password = password,
                        name = name,
                        studentId = studentId,
                        birthDate = "not set",
                        gender = "not set",
                        phoneNumber = "not set",
                        emergencyNumber = "not set"
                    )
                    AppData.users.add(newUser)
                    Toast.makeText(this, "Account created! Please sign in.", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, LoginActivity::class.java))
                    finish()
                }
            }
        }
        signInText.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}

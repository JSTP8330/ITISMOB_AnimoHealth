package com.itismob.s15.group6.mco2.animohealth

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.itismob.s15.group6.mco2.animohealth.utils.SharedPrefsHelper
import com.google.firebase.auth.FirebaseAuth
import com.itismob.s15.group6.mco2.animohealth.utils.NotificationHelper

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize notification channel
        NotificationHelper.createNotificationChannel(this)

        // Test Firestore functionality
        FirestoreHelper.getAllUsers()

        // Check Firebase Auth state
        val auth = FirebaseAuth.getInstance()
        val currentUser = auth.currentUser

        if (currentUser != null) {
            // User is signed in with Firebase Auth
            SharedPrefsHelper.setLoggedIn(this, true)
            SharedPrefsHelper.setCurrentUserId(this, currentUser.uid)
            startActivity(Intent(this, HomeActivity::class.java))
        } else {
            // No user signed in
            SharedPrefsHelper.setLoggedIn(this, false)
            startActivity(Intent(this, LoginActivity::class.java))
        }
        finish()
    }
}
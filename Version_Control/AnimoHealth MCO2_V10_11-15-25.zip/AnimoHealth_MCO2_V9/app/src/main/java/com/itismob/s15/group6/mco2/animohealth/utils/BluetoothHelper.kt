package com.itismob.s15.group6.mco2.animohealth.utils

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat

object BluetoothHelper {

    private const val TAG = "BluetoothHelper"

    // Expected beacon/device names or MAC addresses for clinic proximity
    private val CLINIC_BEACON_NAMES = listOf(
        "DLSU_HEALTH_CLINIC",
        "HealthServices_Beacon",
        "Clinic_BLE"
    )

    fun hasBluetoothPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_SCAN
            ) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH
            ) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_ADMIN
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun isBluetoothEnabled(context: Context): Boolean {
        val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val bluetoothAdapter = bluetoothManager.adapter
        return bluetoothAdapter?.isEnabled == true
    }

    fun scanForClinicBeacon(
        context: Context,
        onBeaconFound: (String) -> Unit,
        onScanFailed: (String) -> Unit
    ) {
        if (!hasBluetoothPermission(context)) {
            onScanFailed("Bluetooth permission not granted")
            return
        }

        if (!isBluetoothEnabled(context)) {
            onScanFailed("Bluetooth is not enabled")
            return
        }

        val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val bluetoothAdapter = bluetoothManager.adapter
        val bluetoothLeScanner: BluetoothLeScanner? = bluetoothAdapter?.bluetoothLeScanner

        if (bluetoothLeScanner == null) {
            onScanFailed("Bluetooth LE scanner not available")
            return
        }

        val scanCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult?) {
                super.onScanResult(callbackType, result)
                result?.let { scanResult ->
                    val device: BluetoothDevice = scanResult.device
                    val deviceName = try {
                        device.name
                    } catch (e: SecurityException) {
                        null
                    }

                    Log.d(TAG, "Found device: $deviceName, Address: ${device.address}")

                    // Check if device matches clinic beacon
                    if (deviceName != null && CLINIC_BEACON_NAMES.any {
                        deviceName.contains(it, ignoreCase = true)
                    }) {
                        onBeaconFound(deviceName)
                        bluetoothLeScanner.stopScan(this)
                    }
                }
            }

            override fun onScanFailed(errorCode: Int) {
                super.onScanFailed(errorCode)
                Log.e(TAG, "Bluetooth scan failed with error code: $errorCode")
                onScanFailed("Scan failed with error code: $errorCode")
            }
        }

        try {
            bluetoothLeScanner.startScan(scanCallback)

            // Auto-stop scan after 10 seconds
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                try {
                    bluetoothLeScanner.stopScan(scanCallback)
                    onScanFailed("No clinic beacon found nearby")
                } catch (e: SecurityException) {
                    Log.e(TAG, "Security exception stopping scan", e)
                }
            }, 10000)
        } catch (e: SecurityException) {
            Log.e(TAG, "Security exception starting scan", e)
            onScanFailed("Permission error: ${e.message}")
        }
    }

    fun getPairedDevices(context: Context): List<BluetoothDevice> {
        if (!hasBluetoothPermission(context)) {
            return emptyList()
        }

        val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val bluetoothAdapter = bluetoothManager.adapter

        return try {
            bluetoothAdapter?.bondedDevices?.toList() ?: emptyList()
        } catch (e: SecurityException) {
            Log.e(TAG, "Security exception getting paired devices", e)
            emptyList()
        }
    }
}


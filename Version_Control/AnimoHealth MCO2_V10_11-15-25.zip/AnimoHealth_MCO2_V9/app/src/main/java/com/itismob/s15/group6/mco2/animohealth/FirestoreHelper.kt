package com.itismob.s15.group6.mco2.animohealth

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.itismob.s15.group6.mco2.animohealth.model.Appointment
import com.itismob.s15.group6.mco2.animohealth.model.Certificate

object FirestoreHelper {

    private val db = FirebaseFirestore.getInstance()
    private const val USERS_COLLECTION = "users"
    private const val APPOINTMENTS_COLLECTION = "appointments"
    private const val CERTIFICATES_COLLECTION = "certificates"
    private const val FEEDBACK_COLLECTION = "feedback"
    private const val SLOTS_COLLECTION = "available_slots"

    // ========== USER OPERATIONS ==========

    fun addUser(userId: String, name: String, email: String, callback: (Boolean) -> Unit) {
        val user = hashMapOf(
            "id" to userId,
            "name" to name,
            "email" to email,
            "createdAt" to System.currentTimeMillis()
        )

        db.collection(USERS_COLLECTION).document(userId)
            .set(user)
            .addOnSuccessListener {
                Log.d("FirestoreHelper", "User added successfully: $userId")
                callback(true)
            }
            .addOnFailureListener { e ->
                Log.w("FirestoreHelper", "Error adding user", e)
                callback(false)
            }
    }

    fun getUser(userId: String, callback: (Map<String, Any>?) -> Unit) {
        db.collection(USERS_COLLECTION).document(userId)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    callback(document.data)
                } else {
                    callback(null)
                }
            }
            .addOnFailureListener { e ->
                Log.w("FirestoreHelper", "Error getting user", e)
                callback(null)
            }
    }

    fun getAllUsers() {
        db.collection(USERS_COLLECTION)
            .get()
            .addOnSuccessListener { result ->
                val users = mutableListOf<Map<String, Any>>()
                for (document in result) {
                    users.add(document.data)
                }
                Log.d("FirestoreHelper", "Users: $users")
            }
            .addOnFailureListener { e ->
                Log.w("FirestoreHelper", "Error getting users", e)
            }
    }

    fun updateUser(userId: String, updates: Map<String, Any>, callback: (Boolean) -> Unit) {
        db.collection(USERS_COLLECTION).document(userId)
            .update(updates)
            .addOnSuccessListener {
                Log.d("FirestoreHelper", "User updated: $userId")
                callback(true)
            }
            .addOnFailureListener { e ->
                Log.w("FirestoreHelper", "Error updating user", e)
                callback(false)
            }
    }

    // ========== APPOINTMENT OPERATIONS ==========

    fun addAppointment(userId: String, appointment: Appointment, callback: (String?) -> Unit) {
        val appointmentData = hashMapOf(
            "userId" to userId,
            "title" to appointment.title,
            "date" to appointment.date,
            "time" to appointment.time,
            "details" to appointment.details,
            "status" to appointment.status,
            "createdAt" to System.currentTimeMillis()
        )

        db.collection(APPOINTMENTS_COLLECTION).add(appointmentData)
            .addOnSuccessListener { documentReference ->
                Log.d("FirestoreHelper", "Appointment added: ${documentReference.id}")
                callback(documentReference.id)
            }
            .addOnFailureListener { e ->
                Log.w("FirestoreHelper", "Error adding appointment", e)
                callback(null)
            }
    }

    fun getAppointments(userId: String, callback: (List<Appointment>) -> Unit) {
        db.collection(APPOINTMENTS_COLLECTION)
            .whereEqualTo("userId", userId)
            .get()
            .addOnSuccessListener { result ->
                val appointments = mutableListOf<Appointment>()
                for (document in result) {
                    val appointment = Appointment(
                        id = document.id,
                        title = document.getString("title") ?: "",
                        date = document.getString("date") ?: "",
                        time = document.getString("time") ?: "",
                        details = document.getString("details") ?: "",
                        status = document.getString("status") ?: "",
                        userIdApp = document.getString("userId") ?: ""
                    )
                    appointments.add(appointment)
                }
                Log.d("FirestoreHelper", "Fetched ${appointments.size} appointments for userId: $userId")
                callback(appointments)
            }
            .addOnFailureListener { e ->
                Log.w("FirestoreHelper", "Error getting appointments", e)
                callback(emptyList())
            }
    }

    fun getAllAppointments(callback: (List<Appointment>) -> Unit) {
        db.collection(APPOINTMENTS_COLLECTION)
            .get()
            .addOnSuccessListener { result ->
                val allAppointments = mutableListOf<Appointment>()
                for (document in result) {
                    val appointment = Appointment(
                        id = document.id,
                        title = document.getString("title") ?: "",
                        date = document.getString("date") ?: "",
                        time = document.getString("time") ?: "",
                        details = document.getString("details") ?: "",
                        status = document.getString("status") ?: "",
                        userIdApp = document.getString("userId") ?: ""
                    )
                    allAppointments.add(appointment)
                }
                callback(allAppointments)
            }
            .addOnFailureListener { e ->
                callback(emptyList())
            }
    }

    fun updateAppointment(appointmentId: String, updates: Map<String, Any>, callback: (Boolean) -> Unit) {
        db.collection(APPOINTMENTS_COLLECTION).document(appointmentId)
            .update(updates)
            .addOnSuccessListener {
                Log.d("FirestoreHelper", "Appointment updated: $appointmentId")
                callback(true)
            }
            .addOnFailureListener { e ->
                Log.w("FirestoreHelper", "Error updating appointment", e)
                callback(false)
            }
    }

    fun deleteAppointment(appointmentId: String, callback: (Boolean) -> Unit) {
        db.collection(APPOINTMENTS_COLLECTION).document(appointmentId)
            .delete()
            .addOnSuccessListener {
                Log.d("FirestoreHelper", "Appointment deleted: $appointmentId")
                callback(true)
            }
            .addOnFailureListener { e ->
                Log.w("FirestoreHelper", "Error deleting appointment", e)
                callback(false)
            }
    }

    // ========== CERTIFICATE OPERATIONS ==========

    fun addCertificate(userId: String, certificate: Certificate, callback: (String?) -> Unit) {
        val certificateData = hashMapOf(
            "userId" to userId,
            "title" to certificate.title,
            "issuedDate" to certificate.issuedDate,
            "expiryDate" to certificate.expiryDate,
            "status" to certificate.status,
            "createdAt" to System.currentTimeMillis()
        )

        db.collection(CERTIFICATES_COLLECTION).add(certificateData)
            .addOnSuccessListener { documentReference ->
                Log.d("FirestoreHelper", "Certificate added: ${documentReference.id}")
                callback(documentReference.id)
            }
            .addOnFailureListener { e ->
                Log.w("FirestoreHelper", "Error adding certificate", e)
                callback(null)
            }
    }

    fun getCertificates(userId: String, callback: (List<Certificate>) -> Unit) {
        db.collection(CERTIFICATES_COLLECTION)
            .whereEqualTo("userId", userId)
            .get()
            .addOnSuccessListener { result ->
                val certificates = mutableListOf<Certificate>()
                for (document in result) {
                    val certificate = Certificate(
                        id = document.id,
                        title = document.getString("title") ?: "",
                        issuedDate = document.getString("issuedDate") ?: "",
                        expiryDate = document.getString("expiryDate") ?: "",
                        status = document.getString("status") ?: "",
                        userIdCert = document.getString("userId") ?: ""
                    )
                    certificates.add(certificate)
                }
                Log.d("FirestoreHelper", "Fetched ${certificates.size} certificates for userId: $userId")
                callback(certificates)
            }
            .addOnFailureListener { e ->
                Log.w("FirestoreHelper", "Error getting certificates", e)
                callback(emptyList())
            }
    }

    fun updateCertificate(certificateId: String, updates: Map<String, Any>, callback: (Boolean) -> Unit) {
        db.collection(CERTIFICATES_COLLECTION).document(certificateId)
            .update(updates)
            .addOnSuccessListener {
                Log.d("FirestoreHelper", "Certificate updated: $certificateId")
                callback(true)
            }
            .addOnFailureListener { e ->
                Log.w("FirestoreHelper", "Error updating certificate", e)
                callback(false)
            }
    }

    fun deleteCertificate(certificateId: String, callback: (Boolean) -> Unit) {
        db.collection(CERTIFICATES_COLLECTION).document(certificateId)
            .delete()
            .addOnSuccessListener {
                Log.d("FirestoreHelper", "Certificate deleted: $certificateId")
                callback(true)
            }
            .addOnFailureListener { e ->
                Log.w("FirestoreHelper", "Error deleting certificate", e)
                callback(false)
            }
    }

    // ========== FEEDBACK OPERATIONS ==========

    fun addFeedback(
        userId: String,
        appointmentId: String,
        rating: Int,
        comments: String,
        callback: (String?) -> Unit
    ) {
        val feedbackData = hashMapOf(
            "userId" to userId,
            "appointmentId" to appointmentId,
            "rating" to rating,
            "comments" to comments,
            "createdAt" to System.currentTimeMillis()
        )

        db.collection(FEEDBACK_COLLECTION).add(feedbackData)
            .addOnSuccessListener { documentReference ->
                Log.d("FirestoreHelper", "Feedback added: ${documentReference.id}")
                callback(documentReference.id)
            }
            .addOnFailureListener { e ->
                Log.w("FirestoreHelper", "Error adding feedback", e)
                callback(null)
            }
    }

    fun getFeedbackForAppointment(appointmentId: String, callback: (Map<String, Any>?) -> Unit) {
        db.collection(FEEDBACK_COLLECTION)
            .whereEqualTo("appointmentId", appointmentId)
            .get()
            .addOnSuccessListener { result ->
                if (!result.isEmpty) {
                    callback(result.documents.first().data)
                } else {
                    callback(null)
                }
            }
            .addOnFailureListener { e ->
                Log.w("FirestoreHelper", "Error getting feedback", e)
                callback(null)
            }
    }

    // ========== AVAILABLE SLOTS OPERATIONS ==========

    fun getAvailableSlots(date: String, callback: (List<String>) -> Unit) {
        db.collection(SLOTS_COLLECTION)
            .whereEqualTo("date", date)
            .get()
            .addOnSuccessListener { result ->
                val slots = mutableListOf<String>()
                for (document in result) {
                    @Suppress("UNCHECKED_CAST")
                    val timeSlots = document.get("timeSlots") as? List<String> ?: emptyList()
                    slots.addAll(timeSlots)
                }
                callback(slots)
            }
            .addOnFailureListener { e ->
                Log.w("FirestoreHelper", "Error getting slots", e)
                callback(emptyList())
            }
    }

}


package com.itismob.s15.group6.mco2.animohealth

import android.app.Application
import com.google.firebase.FirebaseApp

class AnimoHealthApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize Firebase
        FirebaseApp.initializeApp(this)
    }
}

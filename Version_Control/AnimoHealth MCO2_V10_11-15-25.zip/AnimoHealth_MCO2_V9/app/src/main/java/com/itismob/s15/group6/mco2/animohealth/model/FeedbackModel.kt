package com.itismob.s15.group6.mco2.animohealth.model

data class Feedback(
    val id: String,
    val userId: String,
    val appointmentId: String,
    val rating: Int,          // 1-5 stars
    val comments: String,
    val createdAt: Long
)


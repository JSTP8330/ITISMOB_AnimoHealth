import qrcode
import base64
import json
import time
import os

out_dir = os.path.join(os.path.dirname(__file__), '..', 'app', 'src', 'main', 'assets', 'sample_qrs')
os.makedirs(out_dir, exist_ok=True)

for i in range(1, 4):
    payload = json.dumps({
        'aid': f'demo-appt-{i:03d}',
        'uid': 'demo-user-123',
        'ts': int(time.time() * 1000)
    })
    b64 = base64.b64encode(payload.encode('utf-8')).decode('utf-8')
    img = qrcode.make(b64)
    path = os.path.join(out_dir, f'demo_{i:03d}.png')
    img.save(path)
    print('Wrote', path)

print('Done generating sample QR images.')


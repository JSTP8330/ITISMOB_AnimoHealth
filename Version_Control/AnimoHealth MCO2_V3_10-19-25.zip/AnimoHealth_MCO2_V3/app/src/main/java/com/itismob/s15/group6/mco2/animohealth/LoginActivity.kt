package com.itismob.s15.group6.mco2.animohealth
import com.itismob.s15.group6.mco2.animohealth.utils.SharedPrefsHelper

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppData.initializeDemoData()

        setContentView(R.layout.activity_login)

        val emailEditText: EditText = findViewById(R.id.emailEditText)
        val passwordEditText: EditText = findViewById(R.id.passwordEditText)
        val signInButton: Button = findViewById(R.id.signInButton)
        val signUpText: TextView = findViewById(R.id.signUpText)

        //        Easy Sign-In for testing purposes.
        //        signInButton.setOnClickListener {
        //            val email = emailEditText.text.toString().trim().lowercase()
        //            val password = passwordEditText.text.toString()
        //            if (!email.endsWith("@dlsu.edu.ph")) {
        //                Toast.makeText(this, "Please use your university email address", Toast.LENGTH_SHORT).show()
        //            } else {
        //                startActivity(Intent(this, HomeActivity::class.java))
        //                finish()
        //            }
        //        }

        signInButton.setOnClickListener {
            val email = emailEditText.text.toString().trim().lowercase()
            val password = passwordEditText.text.toString()
            if (!email.endsWith("@dlsu.edu.ph")) {
                Toast.makeText(this, "Please use your university email address", Toast.LENGTH_SHORT).show()
            } else {
                val user = AppData.users.find {
                    it.email.lowercase() == email && it.password == password
                }
                if (user != null) {
                    SharedPrefsHelper.setLoggedIn(this, true)
                    SharedPrefsHelper.setCurrentUserId(this, user.id)
                    startActivity(Intent(this, HomeActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show()
                }
            }
        }

        signUpText.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }
}

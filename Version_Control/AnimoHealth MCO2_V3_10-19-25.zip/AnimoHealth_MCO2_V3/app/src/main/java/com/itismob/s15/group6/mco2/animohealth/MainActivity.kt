package com.itismob.s15.group6.mco2.animohealth

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.itismob.s15.group6.mco2.animohealth.utils.SharedPrefsHelper

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppData.initializeDemoData()
            val isLoggedIn = SharedPrefsHelper.isLoggedIn(this)
            if (isLoggedIn) {
                startActivity(Intent(this, HomeActivity::class.java))
            } else {
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
    }
}
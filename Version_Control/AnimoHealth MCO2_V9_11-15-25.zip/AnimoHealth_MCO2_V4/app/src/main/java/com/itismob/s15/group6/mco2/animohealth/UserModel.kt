package com.itismob.s15.group6.mco2.animohealth.model

data class User(
    val id: String,
    var email: String,
    val password: String,
    var name: String,
    var studentId: String,
    var birthDate: String,
    var gender: String,
    var phoneNumber: String,
    var emergencyNumber: String
)
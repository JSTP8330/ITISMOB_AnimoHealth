package com.itismob.s15.group6.mco2.animohealth

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.itismob.s15.group6.mco2.animohealth.adapter.HistoryAdapter
import com.itismob.s15.group6.mco2.animohealth.utils.SharedPrefsHelper
import com.itismob.s15.group6.mco2.animohealth.FirestoreHelper

class HomeActivity : AppCompatActivity() {

    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // USER
        val userId = SharedPrefsHelper.getCurrentUserId(this) ?: return
        Log.d("HomeActivity", "Current userId: $userId")

        // GREETING TEXT
        val greetingText: TextView = findViewById(R.id.greetingText)

        FirestoreHelper.getUser(userId) { userData ->
            if (userData != null) {
                val name = userData["name"] as? String ?: "User"
                val firstName = name.trim().split(" ").firstOrNull()
                    ?.replaceFirstChar { it.uppercase() } ?: "User"
                greetingText.text = "Hi, $firstName!"
            }
        }

        // BOOK NOW
        val bookNowButton: Button = findViewById(R.id.bookNowButton)
        bookNowButton.setOnClickListener {
            startActivity(Intent(this, BookActivity::class.java))
            finish()
        }

        // CHECK IN
        val checkInButton: Button = findViewById(R.id.checkInButton)
        checkInButton.setOnClickListener {
            startActivity(Intent(this, CheckInActivity::class.java))
            finish()
        }

        // ⭐ MY CALENDAR BUTTON
        val myCalendarButton: Button = findViewById(R.id.myCalendarButton)
        myCalendarButton.setOnClickListener {
            startActivity(Intent(this, CalendarActivity::class.java))
        }

        // APPOINTMENTS
        FirestoreHelper.getAppointments(userId) { appointments ->

            val totalAppointments = findViewById<TextView>(R.id.statsTotalAppointments)
            val completedAppointments = findViewById<TextView>(R.id.statsCompletedAppointments)

            totalAppointments.text = "${appointments.size}"
            completedAppointments.text =
                "${appointments.count { it.status == "Completed" }}"

            val upcomingRecycler = findViewById<RecyclerView>(R.id.recyclerHistory)
            val upcomingAdapter =
                HistoryAdapter(appointments.toMutableList(), showDeleteButton = false)

            upcomingRecycler.layoutManager = LinearLayoutManager(this)
            upcomingRecycler.adapter = upcomingAdapter
            upcomingRecycler.isNestedScrollingEnabled = false
        }

        // BOTTOM NAVIGATION
        val navHome: Button = findViewById(R.id.navHome)
        val navBook: Button = findViewById(R.id.navBook)
        val navProfile: Button = findViewById(R.id.navProfile)

        navHome.setOnClickListener {
            // Already here
        }

        navBook.setOnClickListener {
            startActivity(Intent(this, BookActivity::class.java))
            finish()
        }

        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
            finish()
        }
    }
}

package com.itismob.s15.group6.mco2.animohealth

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*
import com.itismob.s15.group6.mco2.animohealth.model.Appointment
import com.itismob.s15.group6.mco2.animohealth.model.Certificate
import com.itismob.s15.group6.mco2.animohealth.utils.SharedPrefsHelper

// 1. Add imports at the top of CheckInActivity.kt
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import android.location.Location
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.itismob.s15.group6.mco2.animohealth.utils.BluetoothHelper
import android.os.Build

class CheckInActivity : AppCompatActivity() {

    //main app proper
    private var step = 0
    private var backPressedOnce = false
    private val backPressResetRunnable = Runnable { backPressedOnce = false }
    private var appointment: Appointment? = null
    private lateinit var confirmedAppointments: List<Appointment>
    private lateinit var spinnerAdapter: ArrayAdapter<String>
    private var certificate: Certificate? = null

    //location verification stuff
    private val LOCATION_PERMISSION_REQUEST_CODE = 100
    private val BLUETOOTH_PERMISSION_REQUEST_CODE = 103
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    private val TARGET_LATITUDE = 14.5639672
    private val TARGET_LONGITUDE = 120.9934338
    private val RADIUS_METERS = 150f

    // QR Scanner launcher
    private val qrScannerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val qrCode = result.data?.getStringExtra(QRScannerActivity.RESULT_QR_CODE)
            if (qrCode != null) {
                Toast.makeText(this, "QR scan successful! Code: $qrCode", Toast.LENGTH_SHORT).show()
                findViewById<Button>(R.id.nextButton).isEnabled = true
            }
        }
    }

    private fun isDeviceNearLocation(
        deviceLat: Double, deviceLon: Double,
        targetLat: Double, targetLon: Double,
        radiusMeters: Float
    ): Boolean {
        val results = FloatArray(1)
        Location.distanceBetween(deviceLat, deviceLon, targetLat, targetLon, results)
        return results[0] <= radiusMeters
    }

    private fun getLocationAndVerify() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return
        }
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            val nextButton = findViewById<Button>(R.id.nextButton)
            if (location != null) {
                val isNear = isDeviceNearLocation(
                    location.latitude, location.longitude,
                    TARGET_LATITUDE, TARGET_LONGITUDE,
                    RADIUS_METERS
                )
                if (isNear) {
                    Toast.makeText(this, "Location verified! You are at the appointment location.", Toast.LENGTH_SHORT).show()
                    nextButton.isEnabled = true
                } else {
                    Toast.makeText(this, "You are not within 150 meters of the location.", Toast.LENGTH_LONG).show()
                    nextButton.isEnabled = false
                }
            } else {
                Toast.makeText(this, "Unable to get current location.", Toast.LENGTH_SHORT).show()
                nextButton.isEnabled = false
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                getLocationAndVerify()
            } else {
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show()
            }
        } else if (requestCode == BLUETOOTH_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                scanForBluetoothBeacon()
            } else {
                Toast.makeText(this, "Bluetooth permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                ),
                BLUETOOTH_PERMISSION_REQUEST_CODE
            )
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.BLUETOOTH,
                    Manifest.permission.BLUETOOTH_ADMIN
                ),
                BLUETOOTH_PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun scanForBluetoothBeacon() {
        Toast.makeText(this, "Scanning for clinic beacon...", Toast.LENGTH_SHORT).show()

        BluetoothHelper.scanForClinicBeacon(
            this,
            onBeaconFound = { beaconName ->
                Toast.makeText(this, "Clinic beacon found: $beaconName", Toast.LENGTH_SHORT).show()
                findViewById<Button>(R.id.nextButton).isEnabled = true
            },
            onScanFailed = { error ->
                Toast.makeText(this, "Bluetooth scan: $error", Toast.LENGTH_LONG).show()
            }
        )
    }

    private fun showFeedbackDialog() {
        val builder = androidx.appcompat.app.AlertDialog.Builder(this)
        val dialogView = layoutInflater.inflate(R.layout.dialog_feedback, null)
        builder.setView(dialogView)

        val ratingBar = dialogView.findViewById<android.widget.RatingBar>(R.id.ratingBar)
        val commentsEditText = dialogView.findViewById<EditText>(R.id.feedbackComments)

        builder.setTitle("Rate Your Experience")
        builder.setPositiveButton("Submit") { dialog, _ ->
            val rating = ratingBar.rating.toInt()
            val comments = commentsEditText.text.toString()

            val userId = SharedPrefsHelper.getCurrentUserId(this) ?: return@setPositiveButton
            val appointmentId = appointment?.id ?: return@setPositiveButton

            FirestoreHelper.addFeedback(userId, appointmentId, rating, comments) { feedbackId ->
                if (feedbackId != null) {
                    Toast.makeText(this, "Thank you for your feedback!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Failed to submit feedback", Toast.LENGTH_SHORT).show()
                }
            }
            dialog.dismiss()
        }
        builder.setNegativeButton("Cancel") { dialog, _ ->
            dialog.dismiss()
        }

        builder.create().show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_check_in)

        val userId = SharedPrefsHelper.getCurrentUserId(this) ?: return

        val spinner = findViewById<Spinner>(R.id.confirmedAppointmentSpinner)
        val stepViews = listOf(
            findViewById<View>(R.id.stepQrLocation),
            findViewById<View>(R.id.stepChecklist),
            findViewById<View>(R.id.stepDone)
        )

        val prevButton = findViewById<Button>(R.id.prevButton)
        val nextButton = findViewById<Button>(R.id.nextButton)
        val appointmentWrapper = findViewById<LinearLayout>(R.id.appointmentWrapper)
        val checklistLayout = findViewById<LinearLayout>(R.id.checkListItems)
        val progressBar = findViewById<ProgressBar>(R.id.progressBar)

        // Load confirmed appointments from Firestore
        FirestoreHelper.getAppointments(userId) { appointments ->
            confirmedAppointments = appointments
                .filter { it.status.equals("Confirmed", ignoreCase = true) }
                .sortedBy { it.date }

            spinnerAdapter = ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                confirmedAppointments.map { "${it.title} (${it.date} ${it.time})" }
            )

            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = spinnerAdapter

            spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                    if (pos in confirmedAppointments.indices) {
                        appointment = confirmedAppointments[pos]
                        certificate = null
                        updateAppointmentCard()
                        updateCertificateCard()
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>) {}
            }

            // Set default appointment
            if (confirmedAppointments.isNotEmpty()) {
                spinner.setSelection(0)
                appointment = confirmedAppointments[0]
            } else {
                appointment = Appointment("0", "No Confirmed Appointments", "", "", "", "", "")
            }

            updateAppointmentCard()
        }

        // Get checklist based on appointment type
        fun getChecklistForTitle(title: String?): List<String> {
            return when (title?.lowercase()) {
                "annual check-up" -> listOf(
                    "Blood pressure measurement",
                    "Weight and height measurement",
                    "Visual acuity test",
                    "General health questionnaire",
                    "X-ray examination"
                )
                "dental check-up" -> listOf(
                    "Dental examination",
                    "Oral hygiene review",
                    "Oral prophylaxis",
                    "Cavity check"
                )
                "drug testing" -> listOf(
                    "Urine sample collection",
                    "Drug analysis",
                    "Review of results"
                )
                else -> listOf("General screening procedure")
            }
        }

        var checklist: List<String>
        var checklistState: MutableList<Boolean>

        // Update UI based on step
        fun updateUi() {
            stepViews.forEachIndexed { i, v -> v.visibility = if (i == step) View.VISIBLE else View.GONE }
            prevButton.isEnabled = step > 0
            progressBar.progress = when (step) { 0 -> 33; 1 -> 66; else -> 100 }

            when (step) {
                0 -> {
                    nextButton.text = "Next"
                    appointmentWrapper.visibility = View.VISIBLE
                    nextButton.isEnabled = false
                }
                1 -> {
                    spinner.visibility = View.GONE
                    checklistLayout.removeAllViews()

                    checklist = getChecklistForTitle(appointment!!.title)
                    checklistState = checklist.map { false }.toMutableList()

                    checklist.forEachIndexed { i, item ->
                        val cb = CheckBox(this)
                        cb.text = item
                        cb.isChecked = checklistState[i]
                        cb.setOnCheckedChangeListener { _, checked ->
                            checklistState[i] = checked
                            nextButton.isEnabled = checklistState.all { it }
                        }
                        checklistLayout.addView(cb)
                    }

                    nextButton.text = "Next"

                    // Button to complete all checkboxes at once
                    findViewById<Button>(R.id.buttonCompleteChecklist).setOnClickListener {
                        for (i in 0 until checklistLayout.childCount) {
                            val view = checklistLayout.getChildAt(i)
                            if (view is CheckBox) {
                                view.isChecked = true
                            }
                        }
                        for (i in checklistState.indices) {
                            checklistState[i] = true
                        }
                        nextButton.isEnabled = true
                    }
                }
                2 -> {
                    spinner.visibility = View.GONE
                    appointmentWrapper.visibility = View.GONE

                    // Update appointment status in Firestore
                    if (appointment!!.status == "Confirmed") {
                        appointment!!.status = "Completed"
                        appointment!!.details = "All vitals normal."

                        // Save updated appointment to Firestore
                        FirestoreHelper.updateAppointment(
                            appointment!!.id.toString(),
                            mapOf(
                                "status" to "Completed",
                                "details" to "All vitals normal."
                            )
                        ) { success ->
                            if (!success) {
                                Toast.makeText(this@CheckInActivity, "Failed to update appointment", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }

                    // Generate certificate if not already created
                    if (certificate == null) {
                        certificate = generateCertificateFromAppointment(appointment!!)
                    }

                    updateCertificateCard()

                    nextButton.text = "Finish"
                    nextButton.isEnabled = true
                }
            }

            updateAppointmentCard()
        }

        prevButton.setOnClickListener {
            if (step > 0) {
                step--
                updateUi()
            }
        }

        nextButton.setOnClickListener {
            if (step == 0 && !nextButton.isEnabled) return@setOnClickListener
            if (step == 1 && !nextButton.isEnabled) return@setOnClickListener

            if (step < stepViews.size - 1) {
                step++
                updateUi()
            } else {
                startActivity(Intent(this, ProfileActivity::class.java))
                finish()
            }
        }

        findViewById<Button>(R.id.buttonScanQr).setOnClickListener {
            val intent = Intent(this, QRScannerActivity::class.java)
            qrScannerLauncher.launch(intent)
        }

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        findViewById<Button>(R.id.buttonScanLocation).setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                getLocationAndVerify()
            } else {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), LOCATION_PERMISSION_REQUEST_CODE)
            }
        }

        findViewById<Button>(R.id.buttonScanBluetooth).setOnClickListener {
            if (BluetoothHelper.hasBluetoothPermission(this)) {
                scanForBluetoothBeacon()
            } else {
                requestBluetoothPermissions()
            }
        }

        // Feedback button handler
        findViewById<Button>(R.id.buttonFeedback).setOnClickListener {
            showFeedbackDialog()
        }

        updateUi()
    }

    @SuppressLint("GestureBackNavigation")
    override fun onBackPressed() {
        if (step > 0) {
            step--
            findViewById<Button>(R.id.prevButton).performClick()
            return
        }

        if (backPressedOnce) {
            super.onBackPressed()
            val intent = Intent(this, HomeActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
            return
        }

        backPressedOnce = true
        Toast.makeText(this, "Press back again to go home", Toast.LENGTH_SHORT).show()

        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(backPressResetRunnable, 2000)
    }


    private fun generateCertificateFromAppointment(appt: Appointment): Certificate {
        val userId = SharedPrefsHelper.getCurrentUserId(this) ?: return Certificate("", "", "", "", "", "")

        val issuedDate = appt.date
        val expiryDate = addExpiryDate(issuedDate)
        val cert = Certificate(
            id = generateCertificateId(),  // Now returns String
            title = appt.title,
            issuedDate = issuedDate,
            expiryDate = expiryDate,
            status = "Valid",
            userIdCert = userId
        )

        FirestoreHelper.addCertificate(userId, cert) { certificateId ->
            if (certificateId != null) {
                Toast.makeText(this, "Certificate generated!", Toast.LENGTH_SHORT).show()
            }
        }

        return cert
    }



    private fun generateCertificateId(): String {
        return System.currentTimeMillis().toString()  // String ID
    }

    private fun addExpiryDate(dateStr: String): String {
        val format = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val cal = Calendar.getInstance()
        return try {
            cal.time = format.parse(dateStr)!!
            cal.add(Calendar.YEAR, 1)
            cal.add(Calendar.DAY_OF_YEAR, 14)
            format.format(cal.time)
        } catch (_: Exception) {
            dateStr
        }
    }

    @SuppressLint("SetTextI18n")
    private fun updateAppointmentCard() {
        if (appointment == null) return  // Guard clause

        findViewById<TextView>(R.id.appointmentTitle).text = appointment!!.title
        findViewById<TextView>(R.id.appointmentStatus).text =
            appointment!!.status.replaceFirstChar { it.uppercase() }
        findViewById<TextView>(R.id.appointmentDateTime).text =
            "${appointment!!.date} · ${appointment!!.time}"
        findViewById<TextView>(R.id.appointmentDetails).text = appointment!!.details
    }

    private fun updateCertificateCard() {
        findViewById<TextView>(R.id.certTitle).text = certificate?.title ?: ""
        findViewById<TextView>(R.id.certStatus).text = certificate?.status ?: ""
        findViewById<TextView>(R.id.certIssued).text =
            getString(R.string.certificate_issued, certificate?.issuedDate ?: "")
        findViewById<TextView>(R.id.certExpires).text =
            getString(R.string.certificate_expires, certificate?.expiryDate ?: "")
    }


}

package com.itismob.s15.group6.mco2.animohealth.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.itismob.s15.group6.mco2.animohealth.MainActivity
import com.itismob.s15.group6.mco2.animohealth.R
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

object NotificationHelper {

    private const val CHANNEL_ID = "appointment_reminders"
    private const val CHANNEL_NAME = "Appointment Reminders"

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for upcoming appointments"
                enableLights(true)
                enableVibration(true)
            }

            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun scheduleAppointmentReminders(
        context: Context,
        appointmentId: String,
        appointmentTitle: String,
        appointmentDate: String,
        appointmentTime: String
    ) {
        try {
            val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            val appointmentDateTime = dateFormat.parse("$appointmentDate ${convertTo24Hour(appointmentTime)}")

            if (appointmentDateTime != null) {
                val currentTime = System.currentTimeMillis()
                val appointmentMillis = appointmentDateTime.time

                // Schedule 3-day reminder
                val threeDaysBefore = appointmentMillis - TimeUnit.DAYS.toMillis(3)
                if (threeDaysBefore > currentTime) {
                    scheduleNotification(
                        context,
                        appointmentId + "_3day",
                        appointmentTitle,
                        "Your appointment is in 3 days on $appointmentDate at $appointmentTime",
                        threeDaysBefore - currentTime
                    )
                }

                // Schedule 1-day reminder
                val oneDayBefore = appointmentMillis - TimeUnit.DAYS.toMillis(1)
                if (oneDayBefore > currentTime) {
                    scheduleNotification(
                        context,
                        appointmentId + "_1day",
                        appointmentTitle,
                        "Your appointment is tomorrow at $appointmentTime",
                        oneDayBefore - currentTime
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun scheduleNotification(
        context: Context,
        workId: String,
        title: String,
        message: String,
        delayMillis: Long
    ) {
        val data = workDataOf(
            "title" to title,
            "message" to message
        )

        val notificationWork = OneTimeWorkRequestBuilder<NotificationWorker>()
            .setInitialDelay(delayMillis, TimeUnit.MILLISECONDS)
            .setInputData(data)
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            workId,
            ExistingWorkPolicy.REPLACE,
            notificationWork
        )
    }

    fun cancelAppointmentReminders(context: Context, appointmentId: String) {
        WorkManager.getInstance(context).cancelUniqueWork(appointmentId + "_3day")
        WorkManager.getInstance(context).cancelUniqueWork(appointmentId + "_1day")
    }

    private fun convertTo24Hour(time: String): String {
        return try {
            val inputFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
            val outputFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
            val date = inputFormat.parse(time)
            outputFormat.format(date ?: Date())
        } catch (e: Exception) {
            "09:00"
        }
    }

    fun showNotification(context: Context, title: String, message: String) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.logo_dlsu)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(System.currentTimeMillis().toInt(), notification)
    }
}

class NotificationWorker(
    context: Context,
    workerParams: WorkerParameters
) : Worker(context, workerParams) {

    override fun doWork(): Result {
        val title = inputData.getString("title") ?: "Appointment Reminder"
        val message = inputData.getString("message") ?: ""

        NotificationHelper.showNotification(applicationContext, title, message)

        return Result.success()
    }
}

